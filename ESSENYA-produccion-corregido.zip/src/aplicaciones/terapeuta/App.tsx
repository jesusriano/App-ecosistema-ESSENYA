import React, { useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { TherapistLayout } from './components/TherapistLayout';
import { TherapistRoutes } from './routes';
import { TherapistRoutePath } from './components/TherapistNavigation';
import { useTerapeuta } from './hooks/useTerapeuta';
import { useAuth } from '../../shared/context/AuthContext';
import { PendingApprovalView } from './pages/PendingApprovalView';

export const TerapeutaAppModule: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();
  const { sessions } = useAuth();
  const { therapist } = useTerapeuta();

  // Check if current therapist account is pending administrative approval
  const isPendingApproval = Boolean(
    sessions.terapeuta?.estado === 'pendiente' ||
    (therapist as any)?.estado === 'pendiente' ||
    (therapist as any)?.estadoAprobacion === 'pendiente' ||
    (therapist as any)?.status === 'pendiente'
  );

  // Derive sub-route from URL path (e.g. /terapeuta/ganancias -> /ganancias)
  const currentRoute: TherapistRoutePath = useMemo(() => {
    const path = location.pathname.replace(/^\/terapeuta/, '') || '/agenda';
    if (path === '/' || path === '') return '/agenda';
    const validRoutes: TherapistRoutePath[] = ['/agenda', '/servicios', '/ganancias', '/calificaciones', '/perfil'];
    const matched = validRoutes.find(r => path.startsWith(r));
    return matched || '/agenda';
  }, [location.pathname]);

  const handleNavigate = (route: TherapistRoutePath) => {
    navigate(`/terapeuta${route}`);
  };

  // Intermediate view: completely blocks access to operational functions until approved
  if (isPendingApproval) {
    return (
      <PendingApprovalView 
        therapistName={therapist?.name || sessions.terapeuta?.nombre}
        email={sessions.terapeuta?.correo || therapist?.email}
      />
    );
  }

  return (
    <TherapistLayout
      therapist={therapist}
      currentRoute={currentRoute}
      onNavigate={handleNavigate}
    >
      <TherapistRoutes currentRoute={currentRoute} />
    </TherapistLayout>
  );
};

export default TerapeutaAppModule;

