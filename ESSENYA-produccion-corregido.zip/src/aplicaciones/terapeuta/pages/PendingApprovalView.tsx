import React, { useState } from 'react';
import { motion } from 'motion/react';
import { 
  ShieldCheck, Clock, FileCheck, PhoneCall, Mail, MessageCircle, 
  LogOut, Home, RefreshCw, Sparkles, CheckCircle2, AlertCircle 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../../shared/context/AuthContext';
import { EssenyaLogo } from '../../../shared/components/EssenyaLogo';

interface PendingApprovalViewProps {
  therapistName?: string;
  email?: string;
}

export const PendingApprovalView: React.FC<PendingApprovalViewProps> = ({
  therapistName = 'Terapeuta',
  email
}) => {
  const navigate = useNavigate();
  const { logout, sessions } = useAuth();
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  const currentEmail = email || sessions.terapeuta?.correo || 'tu correo registrado';
  const displayName = therapistName !== 'Terapeuta' 
    ? therapistName 
    : (sessions.terapeuta?.nombre ? `${sessions.terapeuta.nombre} ${sessions.terapeuta.apellidos || ''}`.trim() : 'Terapeuta');

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      window.location.reload();
    }, 600);
  };

  const handleLogout = async () => {
    await logout('terapeuta');
    navigate('/');
  };

  const verificationSteps = [
    {
      step: 1,
      title: 'Revisión de Identidad y Documentos Oficiales',
      desc: 'Nuestro equipo legal y de seguridad verifica la autenticidad de tu INE/identificación oficial y comprobante de domicilio.',
      icon: FileCheck,
      status: 'en_proceso'
    },
    {
      step: 2,
      title: 'Validación de Certificaciones Profesionales',
      desc: 'Corroboramos tus diplomas, acreditaciones y experiencia técnica en terapias corporales y protocolos holísticos.',
      icon: ShieldCheck,
      status: 'pendiente'
    },
    {
      step: 3,
      title: 'Entrevista y Contacto Telefónico ESSENYA',
      desc: 'Una coordinadora de talento se comunicará contigo vía telefónica o WhatsApp para coordinar tu inducción y bienvenida.',
      icon: PhoneCall,
      status: 'pendiente'
    },
    {
      step: 4,
      title: 'Notificación de Activación por Correo',
      desc: 'Recibirás un correo de confirmación tan pronto como tu panel operativo y perfil en el catálogo exclusivo queden habilitados.',
      icon: Mail,
      status: 'pendiente'
    }
  ];

  return (
    <div className="min-h-screen bg-[#FAF8F5] dark:bg-[#0A0A0A] text-[#1C1917] dark:text-white flex flex-col items-center justify-center p-4 sm:p-6 lg:p-10 font-sans transition-colors">
      {/* Decorative ambient glow */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-72 bg-[#C9A55B]/10 rounded-full blur-3xl pointer-events-none" />

      <motion.div 
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-2xl bg-white dark:bg-[#141414] border-2 border-[#C9A55B]/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative z-10 space-y-8"
      >
        {/* Brand Header */}
        <div className="text-center space-y-3">
          <div className="flex justify-center">
            <EssenyaLogo variant="gold" size="md" />
          </div>
          
          <div className="inline-flex items-center space-x-2 bg-[#C9A55B]/15 border border-[#C9A55B]/50 px-3.5 py-1.5 rounded-full text-xs font-bold text-[#806020] dark:text-[#C9A55B] tracking-wider uppercase">
            <span className="w-2 h-2 rounded-full bg-[#C9A55B] animate-ping" />
            <Clock className="w-3.5 h-3.5" />
            <span>En Revisión Administrativa</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-[#1C1917] dark:text-white">
            Hola, {displayName}
          </h1>
          <p className="text-sm text-[#6B655F] dark:text-[#A3A3A3] max-w-lg mx-auto leading-relaxed">
            Tu registro como terapeuta ha sido recibido correctamente. Para garantizar los más altos estándares de calidad y seguridad para nuestra comunidad, cada expediente pasa por un proceso de acreditación personalizada.
          </p>
        </div>

        {/* Steps Checklist */}
        <div className="space-y-3 bg-[#FAF7F0] dark:bg-[#1C1A17] p-4 sm:p-6 rounded-2xl border border-[#C9A55B]/30">
          <h2 className="text-xs uppercase tracking-widest font-bold text-[#806020] dark:text-[#C9A55B] flex items-center space-x-2">
            <Sparkles className="w-4 h-4" />
            <span>Pasos de Verificación Administrativa</span>
          </h2>

          <div className="space-y-3.5 pt-2">
            {verificationSteps.map((step) => {
              const Icon = step.icon;
              return (
                <div key={step.step} className="flex items-start space-x-3.5">
                  <div className="w-8 h-8 rounded-full bg-white dark:bg-[#262420] border border-[#C9A55B]/40 flex items-center justify-center text-[#806020] dark:text-[#C9A55B] shrink-0 mt-0.5 shadow-sm">
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-bold text-[#1C1917] dark:text-white">
                        {step.step}. {step.title}
                      </span>
                    </div>
                    <p className="text-xs text-[#6B655F] dark:text-[#A3A3A3] mt-0.5 leading-normal">
                      {step.desc}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Notice Info Box */}
        <div className="flex items-start space-x-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 p-4 rounded-xl text-xs text-amber-800 dark:text-amber-200">
          <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
          <p>
            Por motivos de seguridad, el acceso a la agenda, aceptación de reservas y catálogo público permanecerá restringido hasta la finalización de este proceso. Te notificaremos a <strong>{currentEmail}</strong>.
          </p>
        </div>

        {/* Contact Support Channels */}
        <div className="space-y-2.5">
          <h3 className="text-xs uppercase tracking-wider font-bold text-[#6B655F] dark:text-[#A3A3A3]">
            ¿Tienes dudas o deseas agilizar tu entrevista?
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <a
              href="https://wa.me/525512345678?text=Hola%2C%20quisiera%20consultar%20el%20estado%20de%20mi%20registro%20como%20terapeuta%20en%20ESSENYA"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center space-x-2 p-3 rounded-xl border border-emerald-500/40 bg-emerald-50/50 dark:bg-emerald-950/20 hover:bg-emerald-100/50 dark:hover:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 font-semibold text-xs transition-colors"
            >
              <MessageCircle className="w-4 h-4" />
              <span>WhatsApp Soporte (+52 55)</span>
            </a>
            <a
              href="mailto:contacto@essenya.mx?subject=Consulta%20de%20Aprobaci%C3%B3n%20Terapeuta%20ESSENYA"
              className="flex items-center justify-center space-x-2 p-3 rounded-xl border border-[#C9A55B]/40 bg-[#FAF7F0] dark:bg-[#22201C] hover:bg-[#F3EEDF] dark:hover:bg-[#2A2722] text-[#806020] dark:text-[#C9A55B] font-semibold text-xs transition-colors"
            >
              <Mail className="w-4 h-4" />
              <span>contacto@essenya.mx</span>
            </a>
          </div>
        </div>

        {/* Actions Footer */}
        <div className="pt-2 border-t border-[#E5DFD3] dark:border-[#262626] flex flex-col sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="w-full sm:w-auto inline-flex items-center justify-center space-x-2 px-4 py-2.5 rounded-xl border border-[#C9A55B]/50 text-xs font-semibold text-[#806020] dark:text-[#C9A55B] hover:bg-[#C9A55B]/10 transition-colors cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
            <span>Actualizar Estado</span>
          </button>

          <div className="w-full sm:w-auto flex items-center gap-2">
            <button
              type="button"
              onClick={() => navigate('/')}
              className="flex-1 sm:flex-none inline-flex items-center justify-center space-x-1.5 px-4 py-2.5 rounded-xl border border-[#E5DFD3] dark:border-[#333333] text-xs font-medium text-[#6B655F] dark:text-[#CCCCCC] hover:text-[#1C1917] dark:hover:text-white transition-colors cursor-pointer"
            >
              <Home className="w-3.5 h-3.5" />
              <span>Volver al Inicio</span>
            </button>
            <button
              type="button"
              onClick={handleLogout}
              className="flex-1 sm:flex-none inline-flex items-center justify-center space-x-1.5 px-4 py-2.5 rounded-xl border border-red-200 dark:border-red-900/50 bg-red-50/50 dark:bg-red-950/20 text-red-700 dark:text-red-300 text-xs font-medium hover:bg-red-100/50 dark:hover:bg-red-950/40 transition-colors cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Cerrar Sesión</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
