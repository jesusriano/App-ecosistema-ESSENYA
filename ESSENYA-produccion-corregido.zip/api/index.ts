import express, { Request, Response, NextFunction } from "express";
import path from "path";
import fs from "fs";
import { GoogleGenAI } from "@google/genai";
import * as adminApp from "firebase-admin/app";
import * as adminAuth from "firebase-admin/auth";
import * as adminFirestore from "firebase-admin/firestore";

function sanitizePromptInput(input: any, maxLength: number = 500): string {
  if (typeof input !== "string") return "";
  let clean = input.trim().slice(0, maxLength);
  clean = clean.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, "[correo]");
  clean = clean.replace(/(\+?\d{1,3}[\s-]?)?\(?\d{2,4}\)?[\s-]?\d{3,4}[\s-]?\d{4}/g, "[teléfono]");
  clean = clean.replace(/\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b/g, "[tarjeta]");
  return clean;
}

const app = express();
app.use(express.json({ limit: "2mb" }));

// ============================================================================
// 1. FIREBASE ADMIN INITIALIZATION (Requirement 7: Vercel compatible & secure)
// ============================================================================
let firestoreDatabaseId: string | undefined = undefined;

function initFirebaseAdmin() {
  if (adminApp.getApps().length > 0) {
    return;
  }

  const isEmulator = Boolean(
    process.env.FIRESTORE_EMULATOR_HOST ||
    process.env.FIREBASE_AUTH_EMULATOR_HOST ||
    process.env.FIREBASE_STORAGE_EMULATOR_HOST ||
    process.env.NODE_ENV === "test"
  );

  const configPath = path.join(process.cwd(), "firebase-applet-config.json");
  let fileProjectId = "ai-studio-essenya-4bebd9eb-3f06-4b4e-a5fc-4349bc9b5cc8";
  if (fs.existsSync(configPath)) {
    try {
      const parsed = JSON.parse(fs.readFileSync(configPath, "utf-8"));
      if (parsed.projectId) fileProjectId = parsed.projectId;
      if (parsed.firestoreDatabaseId) firestoreDatabaseId = parsed.firestoreDatabaseId;
    } catch (e) {
      console.warn("Failed to parse firebase config:", e);
    }
  }

  const cleanEnvProjectId = process.env.FIREBASE_ADMIN_PROJECT_ID?.replace(/^"|"$/g, "").trim();
  const projectId = isEmulator
    ? (process.env.GCLOUD_PROJECT || "demo-essenya")
    : (cleanEnvProjectId || process.env.GCLOUD_PROJECT || fileProjectId);
  const clientEmail = process.env.FIREBASE_ADMIN_CLIENT_EMAIL?.replace(/^"|"$/g, "").trim();
  const privateKeyRaw = process.env.FIREBASE_ADMIN_PRIVATE_KEY;

  if (isEmulator) {
    // Emulator mode: initialize without requiring real private credentials
    adminApp.initializeApp({ projectId: projectId || "demo-no-project" });
  } else if (clientEmail && privateKeyRaw) {
    // Service Account Credentials provided (Production / Vercel deployment)
    try {
      let privateKey = privateKeyRaw.trim().replace(/^"|"$/g, "").replace(/\\n/g, "\n");
      if (!privateKey.includes("\n") && privateKey.includes("-----BEGIN PRIVATE KEY-----")) {
        privateKey = privateKey
          .replace("-----BEGIN PRIVATE KEY-----", "-----BEGIN PRIVATE KEY-----\n")
          .replace("-----END PRIVATE KEY-----", "\n-----END PRIVATE KEY-----");
      }
      adminApp.initializeApp({
        credential: adminApp.cert({
          projectId,
          clientEmail,
          privateKey
        }),
        projectId
      });
    } catch (certErr) {
      if (process.env.NODE_ENV === "production") {
        throw new Error(`Credenciales de Firebase Admin inválidas: ${certErr instanceof Error ? certErr.message : "certificado inválido"}`);
      }
      console.warn("Could not initialize Firebase Admin credential cert in development, falling back:", certErr);
      adminApp.initializeApp({ projectId });
    }
  } else if (process.env.NODE_ENV !== "production") {
    // Local development container with Application Default Credentials
    adminApp.initializeApp({ projectId });
  } else {
    // Strict production check: halt with clear error if credentials missing
    throw new Error(
      "Configuración de Firebase Admin incompleta en producción. " +
      "Se requieren las variables de entorno FIREBASE_ADMIN_PROJECT_ID, FIREBASE_ADMIN_CLIENT_EMAIL y FIREBASE_ADMIN_PRIVATE_KEY en Vercel."
    );
  }
}

function getAdminAuth() {
  initFirebaseAdmin();
  return adminAuth.getAuth();
}

function getAdminFirestore() {
  initFirebaseAdmin();
  const isEmulator = Boolean(
    process.env.FIRESTORE_EMULATOR_HOST ||
    process.env.FIREBASE_AUTH_EMULATOR_HOST ||
    process.env.NODE_ENV === "test"
  );
  return (!isEmulator && firestoreDatabaseId)
    ? adminFirestore.getFirestore(firestoreDatabaseId)
    : adminFirestore.getFirestore();
}

// ============================================================================
// 2. PERSISTENT RATE LIMITING VIA FIRESTORE (Requirement 2: Vercel Serverless)
// ============================================================================
function getClientIp(req: Request): string {
  const xForwarded = req.headers["x-forwarded-for"];
  let raw = "";
  if (typeof xForwarded === "string") {
    raw = xForwarded.split(",")[0].trim();
  } else if (Array.isArray(xForwarded) && xForwarded.length > 0) {
    raw = xForwarded[0].split(",")[0].trim();
  } else {
    raw = req.socket.remoteAddress || req.ip || "127.0.0.1";
  }
  if (raw.startsWith("::ffff:")) {
    raw = raw.substring(7);
  }
  return raw;
}

async function checkPersistentRateLimit(
  key: string,
  maxRequests: number,
  windowMs: number
): Promise<{ allowed: boolean; retryAfterSeconds: number; remaining: number }> {
  try {
    const db = getAdminFirestore();
    const cleanDocId = Buffer.from(key).toString("base64url").slice(0, 100);
    const docRef = db.collection("rate_limits").doc(cleanDocId);
    const now = Date.now();

    return await db.runTransaction(async (t) => {
      const snap = await t.get(docRef);
      if (!snap.exists) {
        t.set(docRef, {
          key,
          count: 1,
          resetAt: now + windowMs,
          updatedAt: adminFirestore.FieldValue.serverTimestamp()
        });
        return { allowed: true, retryAfterSeconds: Math.ceil(windowMs / 1000), remaining: maxRequests - 1 };
      }

      const data = snap.data() || {};
      let count = Number(data.count) || 0;
      let resetAt = Number(data.resetAt) || (now + windowMs);

      if (now >= resetAt) {
        // Expired window
        t.set(docRef, {
          key,
          count: 1,
          resetAt: now + windowMs,
          updatedAt: adminFirestore.FieldValue.serverTimestamp()
        });
        return { allowed: true, retryAfterSeconds: Math.ceil(windowMs / 1000), remaining: maxRequests - 1 };
      }

      if (count >= maxRequests) {
        const retryAfterSeconds = Math.max(1, Math.ceil((resetAt - now) / 1000));
        return { allowed: false, retryAfterSeconds, remaining: 0 };
      }

      count += 1;
      t.update(docRef, {
        count,
        updatedAt: adminFirestore.FieldValue.serverTimestamp()
      });
      const retryAfterSeconds = Math.max(1, Math.ceil((resetAt - now) / 1000));
      return { allowed: true, retryAfterSeconds, remaining: Math.max(0, maxRequests - count) };
    });
  } catch (err) {
    // In emulator test mode or network error: never fail open silently
    console.error("Persistent rate limit error:", err);
    return { allowed: false, retryAfterSeconds: 30, remaining: 0 };
  }
}

async function rateLimiterMiddleware(req: Request, res: Response, next: NextFunction): Promise<void> {
  // CRITICAL: Only rate-limit backend API endpoints (/api/*), NEVER frontend assets, Vite modules, CSS, HTML
  if (!req.path.startsWith("/api/")) {
    return next();
  }

  // Health checks should never be rate limited
  if (req.path === "/api/health") {
    return next();
  }

  let identifier = getClientIp(req);
  let prefix = "general";
  let maxRequests = 100;
  let windowMs = 60 * 1000;

  // Verify token securely using verifyIdToken if present (never trust unverified payload)
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    try {
      const token = authHeader.split(" ")[1];
      const decoded = await getAdminAuth().verifyIdToken(token);
      if (decoded && decoded.uid) {
        identifier = decoded.uid;
        (req as any).user = decoded; // Cache verified token
      }
    } catch {
      // Invalid token: identifier stays normalized IP
    }
  }

  // Apply separate limits according to requirement 2:
  if (req.path === "/api/therapist/register") {
    // Public registration: max 5 attempts per hour per IP
    maxRequests = 5;
    windowMs = 60 * 60 * 1000;
    prefix = "reg_ip";
    identifier = getClientIp(req); // Always IP for registration
  } else if (req.path === "/api/admin/verify-therapist-auth" || req.path === "/api/admin/create-therapist-auth-profile") {
    // Verification and account creation: max 10 requests per minute per UID
    maxRequests = 10;
    windowMs = 60 * 1000;
    prefix = "acc_verify";
  } else if (req.path.startsWith("/api/admin/")) {
    // Administration: max 20 requests per minute per UID
    maxRequests = 20;
    windowMs = 60 * 1000;
    prefix = "admin";
  } else if (req.path.startsWith("/api/gemini/")) {
    // Gemini: max 30 requests per minute per UID
    maxRequests = 30;
    windowMs = 60 * 1000;
    prefix = "gemini";
  }

  const result = await checkPersistentRateLimit(`${prefix}:${identifier}`, maxRequests, windowMs);

  if (!result.allowed) {
    res.set("Retry-After", String(result.retryAfterSeconds));
    res.status(429).json({
      success: false,
      error: `Límite alcanzado. Espera ${result.retryAfterSeconds}s.`,
      retryAfter: result.retryAfterSeconds
    });
    return;
  }

  res.set("X-RateLimit-Remaining", String(result.remaining));
  next();
}

app.use(rateLimiterMiddleware);

// ============================================================================
// 3. AUTHENTICATION & RBAC MIDDLEWARES (Requirement 6: Master Admin Only)
// ============================================================================
async function requireAuth(req: Request, res: Response, next: NextFunction): Promise<void | any> {
  if ((req as any).user) {
    return next();
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ success: false, error: "Falta token Bearer." });
  }

  try {
    const token = authHeader.split(" ")[1];
    const decodedToken = await getAdminAuth().verifyIdToken(token);
    (req as any).user = decodedToken;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, error: "Token inválido o expirado." });
  }
}

async function requireAdmin(req: Request, res: Response, next: NextFunction): Promise<void | any> {
  await requireAuth(req, res, async () => {
    const uid = (req as any).user.uid;
    const email = (req as any).user.email;
    const user = (req as any).user;

    // Requirement 6: The ONLY master account authorized directly is: essenya222@gmail.com
    // (admin@essenya.com and admin.test.phase1@essenya.com are completely removed)
    if (email === "essenya222@gmail.com") {
      (req as any).user.role = "administrador";
      return next();
    }

    // Los claims están firmados por Firebase Admin, no se leen del body.
    if (user.admin === true || user.role === "administrador" || user.rol === "administrador") {
      (req as any).user.role = "administrador";
      return next();
    }

    // También se admite el registro administrativo activo en Firestore.
    try {
      const db = getAdminFirestore();
      const adminDoc = await db.collection("administradores").doc(uid).get();
      if (adminDoc.exists && adminDoc.data()?.activo !== false) {
        (req as any).user.role = "administrador";
        return next();
      }
    } catch (e) {
      console.warn("Error fetching admin role", e);
    }

    return res.status(403).json({ success: false, error: "No autorizado. Se requiere rol administrador." });
  });
}

async function requireSuperAdmin(req: Request, res: Response, next: NextFunction): Promise<void | any> {
  await requireAuth(req, res, () => {
    if ((req as any).user.email === "essenya222@gmail.com") {
      (req as any).user.role = "administrador";
      return next();
    }
    return res.status(403).json({ success: false, error: "No autorizado. Se requiere superadministrador." });
  });
}

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", environment: process.env.NODE_ENV || "development", timestamp: new Date().toISOString() });
});

// ============================================================================
// 4. THERAPIST REGISTRATION (Requirement 1: Public registration & document validation)
// ============================================================================
app.post("/api/therapist/register", async (req: Request, res: Response) => {
  try {
    const {
      nombre,
      apellidos,
      correo,
      password,
      telefono,
      fotografia,
      fechaNacimiento,
      direccion,
      curp,
      ineNumber,
      certificacionesInfo,
      cuentaBancariaCLABE,
      contactoEmergencia,
      especialidades,
      experienciaAnos,
      disponibilidad,
      zonasCobertura,
      documentos
    } = req.body || {};

    // 1. Validaciones de campos obligatorios
    if (!nombre || typeof nombre !== "string" || !nombre.trim()) {
      return res.status(400).json({ success: false, error: "El nombre es obligatorio." });
    }
    if (!apellidos || typeof apellidos !== "string" || !apellidos.trim()) {
      return res.status(400).json({ success: false, error: "Los apellidos son obligatorios." });
    }
    if (!correo || typeof correo !== "string" || !correo.trim()) {
      return res.status(400).json({ success: false, error: "El correo electrónico es obligatorio." });
    }
    const trimmedEmail = correo.trim().toLowerCase();
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(trimmedEmail)) {
      return res.status(400).json({ success: false, error: "El formato de correo electrónico no es válido." });
    }

    if (!password || typeof password !== "string" || password.length < 6) {
      return res.status(400).json({ success: false, error: "La contraseña debe contener al menos 6 caracteres." });
    }

    if (!telefono || typeof telefono !== "string" || !telefono.trim()) {
      return res.status(400).json({ success: false, error: "El teléfono de contacto es obligatorio." });
    }

    if (curp && typeof curp === "string" && curp.trim().length > 0 && curp.trim().length < 18) {
      return res.status(400).json({ success: false, error: "El CURP debe contener 18 caracteres alfanuméricos." });
    }

    const auth = getAdminAuth();
    const db = getAdminFirestore();

    // 2. Creación en Firebase Authentication
    let userRecord;
    try {
      userRecord = await auth.createUser({
        email: trimmedEmail,
        password: password,
        displayName: `${nombre.trim()} ${apellidos.trim()}`
      });
    } catch (authError: any) {
      if (authError.code === "auth/email-already-exists") {
        return res.status(400).json({
          success: false,
          error: "El correo electrónico ya se encuentra registrado en ESSENYA. Inicia sesión o utiliza otro correo."
        });
      }
      return res.status(400).json({
        success: false,
        error: authError.message || "Error al crear la cuenta de usuario."
      });
    }

    const uid = userRecord.uid;

    // 3. Validación y sanitización estricta de documentos (Requirement 1)
    // No aceptar directamente un arreglo arbitrario enviado por el navegador.
    // Aceptar únicamente rutas de Storage pertenecientes al mismo UID.
    const validDocs = [];
    if (Array.isArray(documentos)) {
      for (const d of documentos) {
        if (d && typeof d === "object") {
          const sPath = typeof d.storagePath === "string" ? d.storagePath : (typeof d.url === "string" ? d.url : "");
          if (sPath.includes(`terapeutas/${uid}/`)) {
            validDocs.push({
              id: typeof d.id === "string" ? d.id.slice(0, 100) : `doc_${Date.now()}`,
              nombre: typeof d.nombre === "string" ? d.nombre.slice(0, 150) : "Documento",
              tipo: typeof d.tipo === "string" ? d.tipo.slice(0, 50) : "expediente",
              storagePath: sPath.slice(0, 500),
              url: typeof d.url === "string" ? d.url.slice(0, 1000) : "",
              fechaSubida: d.fechaSubida || new Date().toISOString(),
              tamanoBytes: typeof d.tamanoBytes === "number" ? Math.min(d.tamanoBytes, 15 * 1024 * 1024) : 0
            });
          }
        }
      }
    }

    // 4. Escritura atómica en Firestore con rollback anti-huérfanos
    try {
      const batch = db.batch();

      // Registro en colección users
      batch.set(db.collection("users").doc(uid), {
        uid,
        email: trimmedEmail,
        correo: trimmedEmail,
        displayName: `${nombre.trim()} ${apellidos.trim()}`,
        nombreCompleto: `${nombre.trim()} ${apellidos.trim()}`,
        role: "terapeuta",
        rol: "terapeuta",
        isActive: false, // Inactiva hasta aprobación por admin
        estado: "pendiente",
        creadoEn: adminFirestore.FieldValue.serverTimestamp(),
        createdAt: adminFirestore.FieldValue.serverTimestamp(),
        updatedAt: adminFirestore.FieldValue.serverTimestamp()
      }, { merge: true });

      // Registro en colección terapeutas
      batch.set(db.collection("terapeutas").doc(uid), {
        id: uid,
        uid,
        nombre: nombre.trim(),
        apellidos: apellidos.trim(),
        nombreCompleto: `${nombre.trim()} ${apellidos.trim()}`,
        correo: trimmedEmail,
        telefono: telefono.trim(),
        fotografia: typeof fotografia === "string" && fotografia.includes(`terapeutas/${uid}/`) ? fotografia : "",
        fechaNacimiento: fechaNacimiento || "",
        direccion: direccion || "",
        curp: (curp || "").toUpperCase().trim(),
        ineNumber: ineNumber || "",
        certificacionesInfo: certificacionesInfo || "",
        cuentaBancariaCLABE: cuentaBancariaCLABE || "",
        contactoEmergencia: contactoEmergencia || { nombre: "", parentesco: "", telefono: "" },
        especialidades: Array.isArray(especialidades) ? especialidades : ["Masaje Tejido Profundo"],
        experienciaAnos: Number(experienciaAnos) || 0,
        disponibilidad: disponibilidad || "Lunes a Sábado, 09:00 - 19:00",
        zonasCobertura: Array.isArray(zonasCobertura) ? zonasCobertura : ["Polanco", "Lomas de Chapultepec"],
        documentos: validDocs,
        estado: "pendiente",
        estadoAprobacion: "pendiente",
        estadoVerificacion: "no_verificado",
        puntuacion: 5.0,
        numeroResenas: 0,
        serviciosCompletados: 0,
        creadoEn: adminFirestore.FieldValue.serverTimestamp(),
        createdAt: adminFirestore.FieldValue.serverTimestamp(),
        updatedAt: adminFirestore.FieldValue.serverTimestamp(),
        solicitudRegistroFecha: adminFirestore.FieldValue.serverTimestamp()
      }, { merge: true });

      // Registro en log de auditoría
      const auditRef = db.collection("audit_logs").doc();
      batch.set(auditRef, {
        actorId: uid,
        actorEmail: trimmedEmail,
        actorRole: "terapeuta_postulante",
        action: "POSTULACION_REGISTRO_TERAPEUTA",
        details: `Nueva postulación de registro recibida para la terapeuta ${nombre.trim()} ${apellidos.trim()} (${trimmedEmail}). Estado: pendiente de revisión.`,
        timestamp: adminFirestore.FieldValue.serverTimestamp(),
        ip: getClientIp(req)
      });

      await batch.commit();

      return res.status(201).json({
        success: true,
        uid,
        message: "Postulación de registro recibida con éxito. Tu cuenta será revisada por el equipo de administración ESSENYA."
      });
    } catch (fsError: any) {
      // Mecanismo anti-huérfanos: Si falla la base de datos, purgar la cuenta Auth recién creada
      try {
        await auth.deleteUser(uid);
      } catch (delErr) {
        console.error("Error eliminando usuario huérfano tras fallo en Firestore:", delErr);
      }
      return res.status(500).json({
        success: false,
        error: "Error interno al guardar la información en la base de datos. Intente de nuevo más tarde."
      });
    }
  } catch (error: any) {
    console.error("Error general en /api/therapist/register:", error);
    return res.status(500).json({
      success: false,
      error: error.message || "Error interno al procesar el registro."
    });
  }
});

// ============================================================================
// 5. TRANSACTIONAL RATINGS (Requirement 9: Atomic rating calculations)
// ============================================================================
app.post("/api/bookings/:bookingId/rating", requireAuth, async (req: Request, res: Response) => {
  try {
    const { bookingId } = req.params;
    const { rating, comment, comentario } = req.body || {};
    const uid = (req as any).user.uid;

    if (!bookingId) {
      return res.status(400).json({ success: false, error: "ID de reserva obligatorio." });
    }

    // Validar calificación entera entre 1 y 5
    const numRating = Number(rating);
    if (!Number.isInteger(numRating) || numRating < 1 || numRating > 5) {
      return res.status(400).json({
        success: false,
        error: "La calificación debe ser un número entero entre 1 y 5 estrellas."
      });
    }

    // Sanitizar comentario
    const cleanComment = typeof comment === "string" ? comment.trim().slice(0, 500) : (typeof comentario === "string" ? comentario.trim().slice(0, 500) : "");

    const db = getAdminFirestore();
    const reservaRef = db.collection("reservas").doc(bookingId);

    // Ejecutar transacción Firestore
    const result = await db.runTransaction(async (transaction) => {
      const reservaDoc = await transaction.get(reservaRef);
      if (!reservaDoc.exists) {
        throw new Error("RESERVA_NOT_FOUND");
      }

      const reserva = reservaDoc.data() || {};

      // Confirmar que la reserva pertenece al cliente autenticado
      const isClientOwner = reserva.clientId === uid || reserva.clienteId === uid;
      const isAdminUser = (req as any).user.email === "essenya222@gmail.com" || (req as any).user.role === "administrador";

      if (!isClientOwner && !isAdminUser) {
        throw new Error("NOT_CLIENT_OWNER");
      }

      // Confirmar que la reserva está en servicio_finalizado
      const isFinished = reserva.state === "servicio_finalizado" || reserva.estado === "servicio_finalizado";
      if (!isFinished) {
        throw new Error("NOT_FINISHED");
      }

      // Confirmar que todavía no fue calificada
      if (reserva.rating !== undefined || reserva.calificada === true || reserva.reviewedAt !== undefined) {
        throw new Error("ALREADY_RATED");
      }

      const therapistId = reserva.therapistId || reserva.terapeutaId;
      let newAverage = numRating;
      let newCount = 1;

      let pubRef: adminFirestore.DocumentReference | null = null;
      let privRef: adminFirestore.DocumentReference | null = null;
      let pubDoc: adminFirestore.DocumentSnapshot | null = null;
      let privDoc: adminFirestore.DocumentSnapshot | null = null;

      if (therapistId) {
        pubRef = db.collection("terapeutas_publicos").doc(therapistId);
        privRef = db.collection("terapeutas").doc(therapistId);

        pubDoc = await transaction.get(pubRef);
        privDoc = await transaction.get(privRef);

        const currentData = pubDoc.exists ? pubDoc.data() : (privDoc.exists ? privDoc.data() : {});
        const oldCount = Number(currentData?.reviewCount || currentData?.numeroResenas || currentData?.resenasCount) || 0;
        const oldRating = Number(currentData?.rating || currentData?.puntuacion) || 5.0;

        newCount = oldCount + 1;
        newAverage = Number(((oldRating * oldCount + numRating) / newCount).toFixed(1));
      }

      // Guardar calificación en reserva
      transaction.update(reservaRef, {
        rating: numRating,
        puntuacion: numRating,
        reviewComment: cleanComment,
        comentarioRating: cleanComment,
        calificada: true,
        reviewedAt: adminFirestore.FieldValue.serverTimestamp(),
        ratedAt: adminFirestore.FieldValue.serverTimestamp(),
        updatedAt: adminFirestore.FieldValue.serverTimestamp()
      });

      // Recalcular promedio de la terapeuta en el servidor y actualizar terapeutas y terapeutas_publicos
      if (therapistId && pubRef && privRef) {
        const updateMetrics = {
          rating: newAverage,
          puntuacion: newAverage,
          reviewCount: newCount,
          numeroResenas: newCount,
          resenasCount: newCount,
          updatedAt: adminFirestore.FieldValue.serverTimestamp()
        };

        if (pubDoc && pubDoc.exists) {
          transaction.update(pubRef, updateMetrics);
        } else {
          transaction.set(pubRef, { id: therapistId, uid: therapistId, ...updateMetrics }, { merge: true });
        }

        if (privDoc && privDoc.exists) {
          transaction.update(privRef, updateMetrics);
        } else {
          transaction.set(privRef, { id: therapistId, uid: therapistId, ...updateMetrics }, { merge: true });
        }
      }

      // Registro de auditoría
      const auditRef = db.collection("audit_logs").doc();
      transaction.set(auditRef, {
        actorId: uid,
        actorEmail: (req as any).user.email || "cliente",
        actorRole: "cliente",
        action: "CALIFICACION_RESERVA_TRANSACCIONAL",
        bookingId,
        therapistId: therapistId || "sin_asignar",
        rating: numRating,
        newAverage,
        newCount,
        timestamp: adminFirestore.FieldValue.serverTimestamp()
      });

      return { newAverage, newCount };
    });

    return res.json({
      success: true,
      bookingId,
      rating: numRating,
      newAverage: result.newAverage,
      newCount: result.newCount,
      message: "Calificación registrada con éxito de forma transaccional."
    });
  } catch (err: any) {
    if (err.message === "RESERVA_NOT_FOUND") {
      return res.status(404).json({ success: false, error: "La reserva indicada no existe." });
    }
    if (err.message === "NOT_CLIENT_OWNER") {
      return res.status(403).json({ success: false, error: "No autorizado. Esta reserva pertenece a otro cliente." });
    }
    if (err.message === "NOT_FINISHED") {
      return res.status(400).json({ success: false, error: "Solo es posible calificar servicios que hayan finalizado (servicio_finalizado)." });
    }
    if (err.message === "ALREADY_RATED") {
      return res.status(400).json({ success: false, error: "Esta reserva ya fue calificada anteriormente. No se permiten calificaciones duplicadas." });
    }

    console.error("Error en calificación transaccional:", err);
    return res.status(500).json({
      success: false,
      error: "Error interno al procesar la calificación transaccional."
    });
  }
});

// ============================================================================
// 6. ADMIN ENDPOINTS
// ============================================================================
app.post("/api/admin/clean-demo-data", requireSuperAdmin, async (req, res) => {
  try {
    const db = getAdminFirestore();
    const batch = db.batch();
    const logs = await db.collection("audit_logs").limit(10).get();
    logs.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
    res.json({ success: true, message: "Datos demo limpiados correctamente." });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/admin/audit-log", requireAdmin, async (req, res) => {
  try {
    const { action, details } = req.body;
    if (!action || !details) return res.status(400).json({ success: false, error: "Datos incompletos" });

    const db = getAdminFirestore();
    await db.collection("audit_logs").add({
      actorId: (req as any).user.uid,
      actorEmail: (req as any).user.email,
      actorRole: (req as any).user.role || "administrador",
      action: action.substring(0, 100),
      details: details.substring(0, 500),
      timestamp: adminFirestore.FieldValue.serverTimestamp(),
      ip: getClientIp(req)
    });
    res.json({ success: true });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/admin/create-therapist-auth-profile", requireAdmin, async (req, res) => {
  try {
    const { email, password, displayName } = req.body;
    if (!email || !password) return res.status(400).json({ success: false, error: "Faltan datos" });

    const auth = getAdminAuth();
    let userRecord;
    let isNewUser = true;
    try {
      userRecord = await auth.createUser({ email, password, displayName });
    } catch (err: any) {
      if (err.code === "auth/email-already-exists") {
        userRecord = await auth.getUserByEmail(email);
        isNewUser = false;
      } else {
        throw err;
      }
    }

    const uid = userRecord.uid;
    const db = getAdminFirestore();

    try {
      const batch = db.batch();
      batch.set(db.collection("users").doc(uid), {
        uid, email, role: "terapeuta", isActive: true, createdAt: adminFirestore.FieldValue.serverTimestamp()
      }, { merge: true });
      batch.set(db.collection("terapeutas").doc(uid), {
        uid, correo: email, nombreCompleto: displayName, estadoAprobacion: "pendiente", estadoVerificacion: "no_verificado"
      }, { merge: true });

      await batch.commit();
      res.json({ success: true, uid });
    } catch (fsError) {
      if (isNewUser) {
        await auth.deleteUser(uid);
        throw new Error("Fallo al escribir en base de datos. Se eliminó la cuenta para evitar huérfanos.");
      } else {
        throw new Error("Fallo al escribir en base de datos.");
      }
    }
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

app.post("/api/admin/verify-therapist-auth", requireAdmin, async (req, res) => {
  try {
    const { uid, email } = req.body;
    let userRecord: adminAuth.UserRecord | null = null;

    if (uid) {
      try {
        userRecord = await getAdminAuth().getUser(uid);
      } catch {
        // Continue to check by email if UID lookup fails
      }
    }

    if (!userRecord && email) {
      try {
        userRecord = await getAdminAuth().getUserByEmail(email);
      } catch {
        // Not found by email
      }
    }

    if (userRecord) {
      return res.json({
        success: true,
        exists: true,
        verified: true,
        uid: userRecord.uid,
        email: userRecord.email
      });
    }

    res.json({ success: true, exists: false, verified: false, error: "Usuario no encontrado en Firebase Auth" });
  } catch (e: any) {
    res.status(500).json({ success: false, exists: false, error: e?.message || "Error al verificar usuario" });
  }
});

// ============================================================================
// 7. GEMINI ENDPOINTS (Requirement 8: Strictly controlled fallback without VITE_FIREBASE_API_KEY)
// ============================================================================
function getGeminiClient(): GoogleGenAI | null {
  const key = process.env.GEMINI_API_KEY;
  if (key && typeof key === "string" && key.trim().length > 0) {
    return new GoogleGenAI({ apiKey: key.trim() });
  }
  return null;
}

app.post("/api/gemini/concierge", requireAuth, async (req, res) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error: "Servicio de Concierge IA no configurado o temporalmente no disponible."
      });
    }

    const { userQuery, userPreferences, muscleTension, occasion } = req.body || {};
    const cleanUserQuery = sanitizePromptInput(userQuery || "Recomiéndame una experiencia según mi estado", 300);
    const cleanTension = sanitizePromptInput(muscleTension || "General / Estrés de trabajo", 200);
    const cleanOccasion = sanitizePromptInput(occasion || "Relajación personal", 100);

    const prompt = `Actúa como Concierge de Alta Gama para ESSENYA Mobile Spa & Wellness.
El cliente solicita: "${cleanUserQuery}"
Tensión muscular: "${cleanTension}"
Ocasión: "${cleanOccasion}"
Devuelve un JSON estricto con:
{
  "recommendedRitual": "nombre exacto del ritual",
  "recommendedDuration": 90,
  "essentialOil": "aceite recomendado",
  "pressureLevel": "Suave | Media | Firme | Profunda",
  "luxuryReasoning": "texto elegante explicando la razón de la selección",
  "conciergeGreeting": "mensaje directo al cliente con tono de concierge de hotel de 5 estrellas"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-flash-latest",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7
      }
    });

    let text = response.text || "{}";
    if (text.includes("```")) {
      text = text.replace(/```json/g, "").replace(/```/g, "").trim();
    }

    res.json({ success: true, recommendation: JSON.parse(text) });
  } catch (error: any) {
    console.error("Concierge Gemini Error:", error?.message || "Unknown");
    res.status(500).json({ success: false, error: "Error al generar recomendación personalizada." });
  }
});

app.post("/api/gemini/match-therapist", requireAuth, async (req, res) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error: "Servicio de Concierge IA no configurado o temporalmente no disponible."
      });
    }

    const { customerLocation, selectedService, duration, genderPreference } = req.body || {};
    const cleanService = sanitizePromptInput(selectedService || "Ritual Holístico Essenya", 100);
    const cleanDuration = Number(duration) || 90;
    const cleanZone = sanitizePromptInput(customerLocation || "Zona Polanco / Lomas", 100);
    const cleanGender = sanitizePromptInput(genderPreference || "Sin preferencia", 50);

    const prompt = `Como Coordinador Clínico de ESSENYA, selecciona el mejor perfil para:
Servicio: "${cleanService}", Duración: ${cleanDuration} min, Zona: "${cleanZone}", Preferencia: "${cleanGender}".
Devuelve un JSON estricto con:
{
  "matchedTherapistId": "id_terapeuta_seleccionada",
  "matchScorePercentage": 98,
  "matchExplanation": "breve explicación sofisticada de por qué este perfil es ideal para la sesión"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-flash-latest",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.3
      }
    });

    let text = response.text || "{}";
    if (text.includes("```")) {
      text = text.replace(/```json/g, "").replace(/```/g, "").trim();
    }

    res.json({ success: true, match: JSON.parse(text) });
  } catch (error: any) {
    console.error("Match Therapist Error:", error?.message || "Unknown error");
    res.status(500).json({ success: false, error: "Error al calcular compatibilidad de terapeuta." });
  }
});

app.post("/api/gemini/post-care", requireAuth, async (req, res) => {
  try {
    const ai = getGeminiClient();
    if (!ai) {
      return res.status(503).json({
        success: false,
        error: "Servicio de Concierge IA no configurado o temporalmente no disponible."
      });
    }

    const { ritualName, therapistNotes } = req.body || {};
    const cleanRitual = sanitizePromptInput(ritualName || "Ritual Holístico Essenya", 100);
    const cleanNotes = sanitizePromptInput(therapistNotes || "Comprensión muscular liberada en zona cervical y lumbar", 300);

    const prompt = `Como Especialista en Bienestar ESSENYA, redacta un protocolo post-masaje de alta gama para el cliente que acaba de finalizar su sesión:
Ritual recibido: "${cleanRitual}"
Notas de evaluación física: "${cleanNotes}"
Devuelve un JSON estricto con:
{
  "hydrationTip": "Recomendación de hidratación o infusión herbal post-sesión",
  "stretchingProtocol": ["Estiramiento 1", "Estiramiento 2"],
  "nextSessionRecommendationDays": 7,
  "careMessage": "Mensaje personalizado de despedida de lujo"
}`;

    const response = await ai.models.generateContent({
      model: "gemini-flash-latest",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.6
      }
    });

    let text = response.text || "{}";
    if (text.includes("```")) {
      text = text.replace(/```json/g, "").replace(/```/g, "").trim();
    }

    res.json({ success: true, protocol: JSON.parse(text) });
  } catch (error: any) {
    console.error("Post Care Error:", error?.message || "Unknown error");
    res.status(500).json({ success: false, error: "Error al generar protocolo de post-cuidado." });
  }
});

app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  res.status(500).json({ success: false, error: "Ocurrió un error inesperado al procesar la solicitud." });
});

export default app;
