import assert from 'node:assert/strict';
import fs from 'node:fs';

const registration = fs.readFileSync('src/shared/components/auth/TherapistRegistrationForm.tsx', 'utf8');
const adminViewer = fs.readFileSync('src/aplicaciones/administrador/pages/TerapeutasPage.tsx', 'utf8');
const backend = fs.readFileSync('api/index.ts', 'utf8');

assert.match(registration, /fetch\('\/api\/therapist\/register'/, 'El registro debe pasar por el backend.');
assert.doesNotMatch(registration, /createUserWithEmailAndPassword/, 'El formulario no debe crear Auth directamente.');
assert.doesNotMatch(registration, /getDownloadURL/, 'No se deben persistir URLs públicas de documentos.');
assert.match(registration, /storagePath: fileRef\.fullPath/, 'Se debe guardar la ruta privada del documento.');
assert.match(adminViewer, /getBlob\(ref\(storage, storagePath\)\)/, 'El admin debe descargar con autenticación.');
assert.match(backend, /process\.env\.NODE_ENV === "production"/, 'Producción debe validar credenciales Admin.');
assert.match(backend, /user\.admin === true/, 'El backend debe reconocer claims firmados.');

console.log('✅ Contratos críticos de producción verificados.');
