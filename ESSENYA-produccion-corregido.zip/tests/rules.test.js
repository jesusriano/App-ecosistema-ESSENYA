import fs from 'fs';
import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';

// ============================================================================
// SUITE REAL DE PRUEBAS DE FIRESTORE Y STORAGE SECURITY RULES (Requisito 3)
// Falla con EXIT CODE 1 si el emulador no responde o alguna regla es vulnerada.
// ============================================================================

async function runRulesTests() {
  console.log("🚀 INICIANDO SUITE DE PRUEBAS DE REGLAS DE SEGURIDAD (FIRESTORE & STORAGE)...");
  
  const projectId = "essenya-test-rules-" + Date.now();
  let testEnv;

  try {
    testEnv = await initializeTestEnvironment({
      projectId,
      firestore: {
        rules: fs.readFileSync('firestore.rules', 'utf8'),
        host: '127.0.0.1',
        port: 8080
      },
      storage: {
        rules: fs.readFileSync('storage.rules', 'utf8'),
        host: '127.0.0.1',
        port: 9199
      }
    });
  } catch (err) {
    console.error("❌ ERROR CRÍTICO: No se pudo conectar al Firebase Emulator Suite.", err);
    process.exit(1); // Falla explícita con código 1 sin silenciar
  }

  let testCount = 0;
  let passedCount = 0;

  async function check(name, fn) {
    testCount++;
    try {
      await fn();
      passedCount++;
      console.log(`  ✅ [PASS] ${name}`);
    } catch (e) {
      console.error(`  ❌ [FAIL] ${name}`);
      console.error("     Detalle del fallo:", e?.message || e);
      throw e;
    }
  }

  try {
    // ------------------------------------------------------------------------
    // A. PRUEBAS DE FIRESTORE RULES
    // ------------------------------------------------------------------------
    console.log("\n--- PRUEBAS DE FIRESTORE SECURITY RULES ---");

    const clientUid = "cliente_real_01";
    const clientEmail = "cliente@essenya.test";
    const clientContext = testEnv.authenticatedContext(clientUid, { email: clientEmail });
    const clientDb = clientContext.firestore();

    const inactiveTherapistUid = "terapeuta_inactiva_01";
    const inactiveTherapistContext = testEnv.authenticatedContext(inactiveTherapistUid, { email: "inactiva@essenya.test" });
    const inactiveTherapistDb = inactiveTherapistContext.firestore();

    const activeTherapistUid = "terapeuta_activa_01";
    const activeTherapistContext = testEnv.authenticatedContext(activeTherapistUid, { email: "activa@essenya.test" });
    const activeTherapistDb = activeTherapistContext.firestore();

    const otherClientUid = "cliente_externo_02";
    const otherClientDb = testEnv.authenticatedContext(otherClientUid, { email: "otro@essenya.test" }).firestore();

    // Setup inicial en base de datos sin reglas
    await testEnv.withSecurityRulesDisabled(async (context) => {
      const db = context.firestore();
      // Terapeuta inactiva
      await db.collection('users').doc(inactiveTherapistUid).set({ uid: inactiveTherapistUid, rol: 'terapeuta', estado: 'pendiente' });
      await db.collection('terapeutas').doc(inactiveTherapistUid).set({ uid: inactiveTherapistUid, estado: 'pendiente' });

      // Terapeuta activa
      await db.collection('users').doc(activeTherapistUid).set({ uid: activeTherapistUid, rol: 'terapeuta', estado: 'activo' });
      await db.collection('terapeutas').doc(activeTherapistUid).set({ uid: activeTherapistUid, estado: 'activo' });

      // Perfil público de terapeuta activa
      await db.collection('terapeutas_publicos').doc(activeTherapistUid).set({
        id: activeTherapistUid,
        nombreCompleto: "Terapeuta Activa",
        biografia: "Especialista en masaje sueco",
        disponibilidad: "Lunes a Viernes",
        zonasCobertura: ["Polanco"],
        telefono: "5512345678",
        rating: 5.0,
        puntuacion: 5.0,
        reviewCount: 10,
        resenasCount: 10
      });

      // Reserva pendiente para pruebas
      await db.collection('reservas').doc('reserva_pendiente_01').set({
        id: 'reserva_pendiente_01',
        clientId: clientUid,
        state: 'pendiente',
        serviceName: 'Masaje Relajante',
        price: 1500
      });

      // Cliente perfil existente
      await db.collection('clientes').doc(clientUid).set({
        uid: clientUid,
        email: clientEmail,
        nombre: "Cliente VIP"
      });
    });

    // 1. Registro de cliente (users/{clientId})
    await check("1. Cliente puede registrar su propio perfil de usuario con rol cliente", async () => {
      await assertSucceeds(clientDb.collection('users').doc(clientUid).set({
        uid: clientUid,
        email: clientEmail,
        rol: 'cliente'
      }));
    });

    // 2. Cliente intentando registrarse con rol 'administrador' (Rechazado)
    await check("2. Cliente NO puede auto-asignarse rol administrador en users/{uid}", async () => {
      await assertFails(clientDb.collection('users').doc(clientUid).set({
        uid: clientUid,
        email: clientEmail,
        rol: 'administrador'
      }));
    });

    // 3. Creación de reserva por cliente
    await check("3. Cliente puede crear una reserva asignada a su propio UID", async () => {
      await assertSucceeds(clientDb.collection('reservas').doc('reserva_nueva_01').set({
        clientId: clientUid,
        serviceName: "Ritual Holístico",
        state: "pendiente"
      }));
    });

    // 4. Creación de reserva ajena por cliente (Rechazado)
    await check("4. Cliente NO puede crear reserva a nombre de otro usuario", async () => {
      await assertFails(clientDb.collection('reservas').doc('reserva_falsa_02').set({
        clientId: "otro_usuario_victima",
        serviceName: "Ritual Holístico",
        state: "pendiente"
      }));
    });

    // 5. Terapeuta inactiva intentando aceptar reserva (Rechazado)
    await check("5. Terapeuta INACTIVA NO puede aceptar reservas ni cambiar su estado", async () => {
      await assertFails(inactiveTherapistDb.collection('reservas').doc('reserva_pendiente_01').update({
        state: 'aceptada',
        therapistId: inactiveTherapistUid
      }));
    });

    // 6. Terapeuta activa aceptando su propia reserva (Permitido)
    await check("6. Terapeuta ACTIVA puede aceptar una reserva pendiente", async () => {
      await assertSucceeds(activeTherapistDb.collection('reservas').doc('reserva_pendiente_01').update({
        state: 'aceptada',
        therapistId: activeTherapistUid,
        therapistName: 'Terapeuta Activa'
      }));
    });

    // 7. Cliente intentando modificar estado o notas administrativas de terapeuta (Rechazado)
    await check("7. Cliente NO puede modificar expediente ni estado de un terapeuta", async () => {
      await assertFails(clientDb.collection('terapeutas').doc(activeTherapistUid).update({
        estado: 'suspendido',
        adminNotes: 'Ataque de prueba'
      }));
    });

    // 8. Modificación directa de terapeutas_publicos violando lista blanca (Rechazado)
    await check("8. Terapeuta NO puede modificar rating/puntuación en terapeutas_publicos (Lista blanca)", async () => {
      await assertFails(activeTherapistDb.collection('terapeutas_publicos').doc(activeTherapistUid).update({
        puntuacion: 5.0,
        rating: 5.0,
        reviewCount: 999
      }));
    });

    // 9. Modificación de terapeutas_publicos respetando lista blanca (Permitido)
    await check("9. Terapeuta SÍ puede modificar biografia y disponibilidad en terapeutas_publicos (Lista blanca)", async () => {
      await assertSucceeds(activeTherapistDb.collection('terapeutas_publicos').doc(activeTherapistUid).update({
        biografia: "Biografía profesional actualizada",
        disponibilidad: "Lunes a Sábado 10:00 - 20:00"
      }));
    });

    // ------------------------------------------------------------------------
    // B. PRUEBAS DE STORAGE RULES
    // ------------------------------------------------------------------------
    console.log("\n--- PRUEBAS DE STORAGE SECURITY RULES ---");

    const storageTherapistUid = "terapeuta_storage_01";
    const storageTherapistContext = testEnv.authenticatedContext(storageTherapistUid, { email: "therapist_storage@test.com" });
    const storageTherapist = storageTherapistContext.storage();

    const otherUserStorage = testEnv.authenticatedContext("usuario_ajeno_02", { email: "ajeno@test.com" }).storage();
    const unauthenticatedStorage = testEnv.unauthenticatedContext().storage();

    // 10. Subida de archivo con extensión/mimetype no permitido (Rechazado)
    await check("10. Storage rechaza archivos no permitidos (.exe, .sh, text/plain)", async () => {
      const badRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/script.sh`);
      await assertFails(badRef.putString("#!/bin/bash\necho hack", "raw", { contentType: "text/x-shellscript" }));
    });

    // 11. Subida de archivo mayor a 15MB (Rechazado)
    await check("11. Storage rechaza archivos de más de 15MB", async () => {
      const bigRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/foto_perfil.jpg`);
      // Simular buffer mayor a 15MB (16MB)
      const bigBuffer = new Uint8Array(16 * 1024 * 1024);
      await assertFails(bigRef.put(bigBuffer, { contentType: "image/jpeg" }));
    });

    // 12. Subida de documento privado en ruta ajena (Rechazado)
    await check("12. Storage rechaza subir archivo en ruta de otra terapeuta (terapeutas/{otro_uid}/...)", async () => {
      const victimRef = otherUserStorage.ref(`terapeutas/${storageTherapistUid}/ine_privada.pdf`);
      const samplePdf = new Uint8Array([0x25, 0x50, 0x44, 0x46]); // %PDF
      await assertFails(victimRef.put(samplePdf, { contentType: "application/pdf" }));
    });

    // 13. Subida de foto pública por la dueña en terapeutas/{uid}/foto_perfil.jpg (Permitido)
    await check("13. Terapeuta dueña SÍ puede subir su foto en terapeutas/{uid}/foto_perfil.jpg", async () => {
      const photoRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/foto_perfil.jpg`);
      const sampleJpg = new Uint8Array([0xFF, 0xD8, 0xFF, 0xE0]); // JPEG magic bytes
      await assertSucceeds(photoRef.put(sampleJpg, { contentType: "image/jpeg" }));
    });

    // 14. Lectura pública de foto en terapeutas/{uid}/foto_*.jpg (Permitido)
    await check("14. Visitante no autenticado SÍ puede ver foto pública terapeutas/{uid}/foto_perfil.jpg", async () => {
      const publicPhotoRef = unauthenticatedStorage.ref(`terapeutas/${storageTherapistUid}/foto_perfil.jpg`);
      await assertSucceeds(publicPhotoRef.getDownloadURL());
    });

    // 15. Subida de documento privado por la dueña en terapeutas/{uid}/ine.pdf (Permitido)
    await check("15. Terapeuta dueña SÍ puede subir documento privado PDF en su propia carpeta", async () => {
      const docRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/ine.pdf`);
      const samplePdf = new Uint8Array([0x25, 0x50, 0x44, 0x46]);
      await assertSucceeds(docRef.put(samplePdf, { contentType: "application/pdf" }));
    });

    // 16. Lectura de documento privado por tercero sin rol admin (Rechazado)
    await check("16. Usuario ajeno NO puede descargar documento privado terapeutas/{uid}/ine.pdf", async () => {
      const privateDocRef = otherUserStorage.ref(`terapeutas/${storageTherapistUid}/ine.pdf`);
      await assertFails(privateDocRef.getDownloadURL());
    });

    await check("17. Storage acepta PNG privado válido de la propietaria", async () => {
      const pngRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/documentos/identificacion.png`);
      await assertSucceeds(pngRef.put(new Uint8Array([0x89, 0x50, 0x4E, 0x47]), { contentType: "image/png" }));
    });

    await check("18. Storage rechaza SVG aunque sea una imagen", async () => {
      const svgRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/documentos/vector.svg`);
      await assertFails(svgRef.putString("<svg></svg>", "raw", { contentType: "image/svg+xml" }));
    });

    await check("19. Storage rechaza extensión PDF con MIME ejecutable", async () => {
      const disguisedRef = storageTherapist.ref(`terapeutas/${storageTherapistUid}/documentos/disfraz.pdf`);
      await assertFails(disguisedRef.put(new Uint8Array([1, 2, 3]), { contentType: "application/x-msdownload" }));
    });

    console.log(`\n🎉 TODAS LAS PRUEBAS DE REGLAS PASARON EXITOSAMENTE: ${passedCount}/${testCount} verificaciones aprobadas.`);
    await testEnv.cleanup();
    process.exit(0);

  } catch (err) {
    console.error("\n❌ SUITE DE PRUEBAS DE REGLAS DETENIDA POR FALLO.");
    if (testEnv) {
      await testEnv.cleanup().catch(() => {});
    }
    process.exit(1);
  }
}

runRulesTests();
