import http from 'http';
import express from 'express';
import { getApps, initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import apiApp from '../api/index.ts';

// Helper to exchange custom token for emulator ID token
async function getIdTokenForUser(auth, uid, email, customClaims = {}) {
  try {
    // Ensure user exists in Auth emulator
    try {
      await auth.getUser(uid);
    } catch {
      await auth.createUser({ uid, email, emailVerified: true });
    }

    const customToken = await auth.createCustomToken(uid, customClaims);
    const authHost = process.env.FIREBASE_AUTH_EMULATOR_HOST || '127.0.0.1:9099';
    const res = await fetch(`http://${authHost}/identitytoolkit.googleapis.com/v1/accounts:signInWithCustomToken?key=fake-key`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: customToken, returnSecureToken: true })
    });
    const data = await res.json();
    return data.idToken;
  } catch (err) {
    console.error(`Error getting ID token for ${email}:`, err);
    throw err;
  }
}

async function runTests() {
  console.log("==================================================");
  console.log("INICIANDO SUITE DE PRUEBAS DE SEGURIDAD Y API ESSENYA");
  console.log("==================================================");

  let passed = true;
  const proj = (process.env.GCLOUD_PROJECT || 'demo-essenya').replace(/^"|"$/g, "");
  
  const apps = getApps();
  const adminApp = apps.length > 0 ? apps[0] : initializeApp({ projectId: proj });

  const auth = getAuth(adminApp);
  const db = getFirestore(adminApp);

  const app = express();
  app.use(apiApp);
  const server = http.createServer(app);
  const PORT = 3002;

  await new Promise((resolve) => server.listen(PORT, resolve));
  const baseUrl = `http://localhost:${PORT}`;

  try {
    // Prepare test identities
    const masterAdminEmail = 'essenya222@gmail.com';
    const clientEmail = 'cliente.test@essenya.mx';
    const otherClientEmail = 'otro.cliente@essenya.mx';
    const therapistEmail = 'terapeuta.test@essenya.mx';
    const attackerEmail = 'hacker@essenya.mx';

    const masterAdminToken = await getIdTokenForUser(auth, 'master-admin-uid-1', masterAdminEmail);
    const clientToken = await getIdTokenForUser(auth, 'client-uid-1', clientEmail);
    const otherClientToken = await getIdTokenForUser(auth, 'other-client-uid-2', otherClientEmail);
    const therapistToken = await getIdTokenForUser(auth, 'therapist-uid-1', therapistEmail);
    const attackerToken = await getIdTokenForUser(auth, 'attacker-uid-1', attackerEmail);
    const delegatedAdminToken = await getIdTokenForUser(auth, 'delegated-admin-uid-1', 'admin.delegado@essenya.mx', { admin: true });

    // Seed therapist in terapeutas and terapeutas_publicos
    await db.collection('terapeutas').doc('therapist-uid-1').set({
      id: 'therapist-uid-1',
      uid: 'therapist-uid-1',
      nombre: 'Terapeuta',
      apellidos: 'Test',
      rating: 5.0,
      reviewCount: 0
    });
    await db.collection('terapeutas_publicos').doc('therapist-uid-1').set({
      id: 'therapist-uid-1',
      uid: 'therapist-uid-1',
      nombre: 'Terapeuta',
      apellidos: 'Test',
      rating: 5.0,
      reviewCount: 0
    });

    // Seed test bookings for rating tests
    const bookingFinishedId = 'booking-test-finished-01';
    await db.collection('reservas').doc(bookingFinishedId).set({
      id: bookingFinishedId,
      clientId: 'client-uid-1',
      therapistId: 'therapist-uid-1',
      state: 'servicio_finalizado',
      estado: 'servicio_finalizado',
      serviceName: 'Masaje Descontracturante',
      fecha: new Date().toISOString()
    });

    const bookingOtherClientId = 'booking-test-other-client-02';
    await db.collection('reservas').doc(bookingOtherClientId).set({
      id: bookingOtherClientId,
      clientId: 'other-client-uid-2',
      therapistId: 'therapist-uid-1',
      state: 'servicio_finalizado',
      estado: 'servicio_finalizado',
      serviceName: 'Ritual Holístico',
      fecha: new Date().toISOString()
    });

    const bookingUnfinishedId = 'booking-test-unfinished-03';
    await db.collection('reservas').doc(bookingUnfinishedId).set({
      id: bookingUnfinishedId,
      clientId: 'client-uid-1',
      therapistId: 'therapist-uid-1',
      state: 'en_camino',
      estado: 'en_camino',
      serviceName: 'Masaje Relajante',
      fecha: new Date().toISOString()
    });

    // -------------------------------------------------------------
    // Test 1: Registro público con datos válidos -> 201 y creación de usuario
    // -------------------------------------------------------------
    try {
      const validTherapist = {
        nombre: 'Valeria',
        apellidos: 'Herrera Gómez',
        correo: `valeria.registro.${Date.now()}@essenya.mx`,
        password: 'Password123!Valeria',
        telefono: '5512345678',
        especialidades: ['Masaje Tejido Profundo', 'Drenaje Linfático'],
        experienciaAnos: 6,
        disponibilidad: 'Lunes a Sábado, 09:00 - 19:00',
        zonasCobertura: ['Polanco', 'Lomas de Chapultepec']
      };

      const res = await fetch(`${baseUrl}/api/therapist/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(validTherapist)
      });
      const data = await res.json();

      if (res.status === 201 && data.success === true && (data.therapistId || data.uid)) {
        console.log('✅ Test 1: Registro público con datos válidos -> 201 y creación de usuario.');
      } else {
        console.error(`❌ Test 1 falló, status: ${res.status}`, data);
        passed = false;
      }
    } catch (e) {
      console.error('Test 1 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 2: Registro público con contraseña corta o datos inválidos -> 400
    // -------------------------------------------------------------
    try {
      const res = await fetch(`${baseUrl}/api/therapist/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: 'Elena',
          apellidos: 'Torres',
          correo: 'elena@essenya.mx',
          telefono: '5511223344',
          password: '123' // Contraseña débil
        })
      });
      if (res.status === 400) {
        console.log('✅ Test 2: Registro público con contraseña corta o datos inválidos -> 400.');
      } else {
        console.error(`❌ Test 2 falló, status: ${res.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 2 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 3: Registro público con correo duplicado -> 400
    // -------------------------------------------------------------
    try {
      const dupEmail = `duplicado.${Date.now()}@essenya.mx`;
      // Primer registro exitoso
      await fetch(`${baseUrl}/api/therapist/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: 'Camila',
          apellidos: 'Sosa',
          correo: dupEmail,
          password: 'Password123!Secure',
          telefono: '5588776655',
          especialidades: ['Holístico'],
          experienciaAnos: 3,
          disponibilidad: 'Lunes a Viernes',
          zonasCobertura: ['Condesa']
        })
      });

      // Segundo registro con mismo correo -> debe retornar 400
      const resDup = await fetch(`${baseUrl}/api/therapist/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nombre: 'Camila',
          apellidos: 'Sosa',
          correo: dupEmail,
          password: 'Password123!Secure',
          telefono: '5588776655'
        })
      });

      if (resDup.status === 400) {
        console.log('✅ Test 3: Registro público con correo duplicado -> 400.');
      } else {
        console.error(`❌ Test 3 falló, status: ${resDup.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 3 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 4: Persistencia de rate limiting: 6to intento desde la misma IP -> 429 con Retry-After
    // -------------------------------------------------------------
    try {
      const testIp = `198.51.100.${Math.floor(Math.random() * 200) + 10}`;
      let hitRateLimit = false;
      let hasRetryAfter = false;

      for (let i = 1; i <= 6; i++) {
        const res = await fetch(`${baseUrl}/api/therapist/register`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-forwarded-for': testIp
          },
          body: JSON.stringify({
            nombre: 'Spam',
            apellidos: 'Test',
            correo: `spam.${i}@test.com`,
            password: '123'
          })
        });

        if (i === 6) {
          if (res.status === 429) {
            hitRateLimit = true;
            if (res.headers.get('Retry-After')) {
              hasRetryAfter = true;
            }
          }
        }
      }

      if (hitRateLimit && hasRetryAfter) {
        console.log('✅ Test 4: Persistencia del rate limiting: 6to intento desde la misma IP -> 429 con Retry-After.');
      } else {
        console.error(`❌ Test 4 falló: hitRateLimit=${hitRateLimit}, hasRetryAfter=${hasRetryAfter}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 4 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 5: Endpoint de administración sin token -> 401
    // -------------------------------------------------------------
    try {
      const res = await fetch(`${baseUrl}/api/admin/audit-log`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'TEST_AUDIT', details: 'Unauthenticated test' })
      });
      if (res.status === 401) {
        console.log('✅ Test 5: Endpoint de administración sin token -> 401.');
      } else {
        console.error(`❌ Test 5 falló, status: ${res.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 5 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 6: Endpoint de administración con token de cliente o terapeuta -> 403
    // -------------------------------------------------------------
    try {
      const resCliente = await fetch(`${baseUrl}/api/admin/audit-log`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${clientToken}`
        },
        body: JSON.stringify({ action: 'TEST_AUDIT', details: 'Client trying admin' })
      });

      const resTerapeuta = await fetch(`${baseUrl}/api/admin/audit-log`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${therapistToken}`
        },
        body: JSON.stringify({ action: 'TEST_AUDIT', details: 'Therapist trying admin' })
      });

      if (resCliente.status === 403 && resTerapeuta.status === 403) {
        console.log('✅ Test 6: Endpoint de administración con token de cliente o terapeuta -> 403.');
      } else {
        console.error(`❌ Test 6 falló: resCliente=${resCliente.status}, resTerapeuta=${resTerapeuta.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 6 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 7: Endpoint de administración con token de essenya222@gmail.com -> 200
    // -------------------------------------------------------------
    try {
      const res = await fetch(`${baseUrl}/api/admin/audit-log`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${masterAdminToken}`
        },
        body: JSON.stringify({ action: 'TEST_MASTER_ADMIN', details: 'Master admin verified' })
      });
      if (res.status === 200) {
        console.log('✅ Test 7: Endpoint de administración con token de essenya222@gmail.com -> 200.');
      } else {
        console.error(`❌ Test 7 falló, status: ${res.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 7 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 8: Un cliente no puede escalar privilegios enviando roles en el body.
    // -------------------------------------------------------------
    try {
      const res = await fetch(`${baseUrl}/api/admin/audit-log`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${attackerToken}`
        },
        body: JSON.stringify({ action: 'TEST_EXPLOIT', details: 'Forged body role', admin: true, role: 'administrador' })
      });
      if (res.status === 403) {
        console.log('✅ Test 8: Rol administrativo falsificado en el body -> rechazado (403).');
      } else {
        console.error(`❌ Test 8 falló, status: ${res.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 8 error:', e);
      passed = false;
    }

    try {
      const res = await fetch(`${baseUrl}/api/admin/audit-log`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${delegatedAdminToken}`
        },
        body: JSON.stringify({ action: 'TEST_DELEGATED_ADMIN', details: 'Signed Firebase claim' })
      });
      if (res.status === 200) {
        console.log('✅ Test 8.1: Claim administrativo firmado -> permitido (200).');
      } else {
        console.error(`❌ Test 8.1 falló, status: ${res.status}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 8.1 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 9: Endpoint transaccional de calificación
    // -------------------------------------------------------------
    try {
      // 9.1: Cliente califica servicio finalizado -> 200 y promedio actualizado
      const resValida = await fetch(`${baseUrl}/api/bookings/${bookingFinishedId}/rating`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${clientToken}`
        },
        body: JSON.stringify({ rating: 5, comment: 'Excelente servicio y puntualidad.' })
      });
      const dataValida = await resValida.json();
      console.log('Test 9.1 resValida:', resValida.status, dataValida);
      const validSuccess = resValida.status === 200 && dataValida.success === true && dataValida.newAverage !== undefined;

      // 9.2: Intento de calificar servicio ajeno -> 403
      const resAjena = await fetch(`${baseUrl}/api/bookings/${bookingOtherClientId}/rating`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${clientToken}` // Client 1 intenta calificar reserva de Client 2
        },
        body: JSON.stringify({ rating: 4 })
      });
      const dataAjena = await resAjena.json();
      console.log('Test 9.2 resAjena:', resAjena.status, dataAjena);
      const ajenaSuccess = resAjena.status === 403;

      // 9.3: Intento de calificar dos veces la misma reserva -> 400
      const resDoble = await fetch(`${baseUrl}/api/bookings/${bookingFinishedId}/rating`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${clientToken}`
        },
        body: JSON.stringify({ rating: 4 })
      });
      const dataDoble = await resDoble.json();
      console.log('Test 9.3 resDoble:', resDoble.status, dataDoble);
      const dobleSuccess = resDoble.status === 400;

      // 9.4: Calificación fuera de rango (0 o 6) -> 400
      const resFueraRango = await fetch(`${baseUrl}/api/bookings/${bookingOtherClientId}/rating`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${otherClientToken}`
        },
        body: JSON.stringify({ rating: 6 })
      });
      const rangoSuccess = resFueraRango.status === 400;

      if (validSuccess && ajenaSuccess && dobleSuccess && rangoSuccess) {
        console.log('✅ Test 9: Endpoint transaccional de calificación verificado integralmente (200, 403, 400 duplicado, 400 fuera de rango).');
      } else {
        console.error(`❌ Test 9 falló: valid=${validSuccess}, ajena=${ajenaSuccess}, doble=${dobleSuccess}, rango=${rangoSuccess}`);
        passed = false;
      }
    } catch (e) {
      console.error('Test 9 error:', e);
      passed = false;
    }

    // -------------------------------------------------------------
    // Test 10: Gemini: llamada sin GEMINI_API_KEY -> 503 o respuesta controlada sin exponer secretos
    // -------------------------------------------------------------
    try {
      const originalKey = process.env.GEMINI_API_KEY;
      delete process.env.GEMINI_API_KEY;

      const res = await fetch(`${baseUrl}/api/gemini/concierge`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${clientToken}`
        },
        body: JSON.stringify({ userQuery: 'Quiero un masaje relajante' })
      });
      const data = await res.json();

      if (originalKey) {
        process.env.GEMINI_API_KEY = originalKey;
      }

      // Debe retornar 503 controlado sin exponer stacktrace ni secretos internos
      if (res.status === 503 && data.success === false && !JSON.stringify(data).includes('stack')) {
        console.log('✅ Test 10: Gemini sin GEMINI_API_KEY -> 503 controlado sin exposición de secretos.');
      } else {
        console.error(`❌ Test 10 falló, status: ${res.status}`, data);
        passed = false;
      }
    } catch (e) {
      console.error('Test 10 error:', e);
      passed = false;
    }
  } finally {
    server.close();
  }

  console.log("==================================================");
  if (!passed) {
    console.error("❌ AL MENOS UNA PRUEBA DE API FALLÓ.");
    process.exit(1);
  } else {
    console.log("✅ TODAS LAS PRUEBAS DE API PASARON SATISFACTORIAMENTE.");
    process.exit(0);
  }
}

runTests().catch((err) => {
  console.error("Fatal test runner error:", err);
  process.exit(1);
});
