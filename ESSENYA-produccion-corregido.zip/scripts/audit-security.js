import { execSync } from "child_process";

console.log("🔒 EJECUTANDO AUDITORÍA DE SEGURIDAD DE DEPENDENCIAS DE PRODUCCIÓN...");

let output = "";
try {
  output = execSync("npm audit --omit=dev --json", { encoding: "utf8", maxBuffer: 10 * 1024 * 1024 });
} catch (error) {
  // npm audit exits with 1 when vulnerabilities exist
  output = error.stdout ? error.stdout.toString() : "";
}

if (!output.trim()) {
  console.log("✅ Sin vulnerabilidades reportadas por npm audit.");
  process.exit(0);
}

try {
  const audit = JSON.parse(output);
  const vulnCounts = audit.metadata?.vulnerabilities || {
    info: 0,
    low: 0,
    moderate: 0,
    high: 0,
    critical: 0,
    total: 0
  };

  console.log("--------------------------------------------------");
  console.log("RESUMEN DE VULNERABILIDADES (PRODUCCIÓN):");
  console.log(`- Críticas:   ${vulnCounts.critical}`);
  console.log(`- Altas:      ${vulnCounts.high}`);
  console.log(`- Moderadas:  ${vulnCounts.moderate}`);
  console.log(`- Bajas/Info: ${vulnCounts.low + vulnCounts.info}`);
  console.log(`- Total:      ${vulnCounts.total}`);
  console.log("--------------------------------------------------");

  if (vulnCounts.moderate > 0) {
    console.log("⚠️ DETALLE DE VULNERABILIDADES MODERADAS:");
    const vulns = audit.vulnerabilities || {};
    for (const [name, details] of Object.entries(vulns)) {
      if (details.severity === "moderate") {
        console.log(`  * Paquete: ${name} (Severidad: moderada)`);
        if (Array.isArray(details.via)) {
          details.via.forEach((v) => {
            if (typeof v === "object" && v.title) {
              console.log(`    - Detalle: ${v.title} (${v.url || ""})`);
            }
          });
        }
      }
    }
  }

  if (vulnCounts.critical > 0 || vulnCounts.high > 0) {
    console.error("❌ FALLO DE SEGURIDAD: Se detectaron vulnerabilidades ALTAS o CRÍTICAS en dependencias de producción.");
    process.exit(1);
  }

  console.log("✅ AUDITORÍA APROBADA: Cero vulnerabilidades altas y cero críticas en dependencias de producción.");
  process.exit(0);
} catch (e) {
  console.error("Error al analizar el informe de auditoría:", e);
  process.exit(1);
}
