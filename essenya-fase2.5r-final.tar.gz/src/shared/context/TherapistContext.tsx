import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { doc, setDoc, getDoc, updateDoc, collection, deleteDoc, onSnapshot } from 'firebase/firestore';
import { sendPasswordResetEmail } from 'firebase/auth';
import { db, auth } from '../../lib/firebase';
import { TherapistFullProfile, TherapistDocument, DocumentStatus, AccountStatus } from '../types/auth';
import { handleFirestoreError, OperationType, cleanForFirestore } from '../utils/firestoreDebug';
import { useAuth } from './AuthContext';

interface AuditLog {
  id: string;
  therapistId: string;
  therapistName: string;
  action: string;
  performedBy: string; // e.g. "Administradora"
  timestamp: string;
  details?: string;
}

interface TherapistContextType {
  therapists: TherapistFullProfile[];
  auditLogs: AuditLog[];
  loading: boolean;
  firestoreError: string | null;
  
  // Admin Operations
  createTherapist: (data: {
    id?: string;
    nombre: string;
    apellidos: string;
    correo: string;
    telefono: string;
    especialidades: string[];
    zonasCobertura: string[];
    tempPassword?: string;
    fotografia?: string;
    fechaNacimiento?: string;
    direccion?: string;
    curp?: string;
    ineNumber?: string;
    certificacionesInfo?: string;
    cuentaBancariaCLABE?: string;
    contactoEmergencia?: { nombre: string; parentesco: string; telefono: string };
    experienciaAnos?: number;
    disponibilidad?: string;
    estado?: AccountStatus;
  }) => Promise<{ success: boolean; tempPassword?: string; error?: string }>;
  
  updateTherapist: (id: string, updates: Partial<TherapistFullProfile>) => Promise<{ success: boolean; error?: string }>;
  changeTherapistStatus: (id: string, status: AccountStatus, reason?: string) => Promise<{ success: boolean; error?: string }>;
  resetTherapistPassword: (id: string) => Promise<{ success: boolean; message?: string; tempPassword?: string; error?: string }>;
  deleteTherapist: (id: string) => Promise<{ success: boolean; error?: string }>;
  
  // Document Verification (Admin)
  reviewDocument: (therapistId: string, documentId: string, status: DocumentStatus, motivoRechazo?: string) => Promise<{ success: boolean; error?: string }>;
  
  // Therapist Self Operations
  uploadDocument: (therapistId: string, docData: Omit<TherapistDocument, 'id' | 'estado' | 'fechaSubida'>) => Promise<{ success: boolean; error?: string }>;
  replaceDocument: (therapistId: string, documentId: string, docData: Partial<Omit<TherapistDocument, 'id' | 'estado' | 'fechaSubida'>>) => Promise<{ success: boolean; error?: string }>;
  deleteDocument: (therapistId: string, documentId: string) => Promise<{ success: boolean; error?: string }>;
  updateSelfProfile: (therapistId: string, updates: Partial<TherapistFullProfile>) => Promise<{ success: boolean; error?: string }>;
  
  getTherapistById: (id: string) => TherapistFullProfile | undefined;
}

const TherapistContext = createContext<TherapistContextType | undefined>(undefined);

// Helper to guarantee complete and non-null data structure for therapists
export const sanitizeTherapist = (raw: any): TherapistFullProfile => {
  const defaultDate = new Date().toISOString();

  if (!raw || typeof raw !== 'object') {
    return {
      id: `therapist-${Date.now()}`,
      nombre: 'Terapeuta',
      apellidos: '',
      correo: '',
      telefono: '',
      fotografia: '',
      especialidades: [],
      experienciaAnos: 1,
      idiomas: ['Español'],
      disponibilidad: 'Lunes a Sábado',
      zonasCobertura: [],
      zonasCoordinadas: [],
      estado: 'pendiente',
      documentos: [],
      puntuacion: 5.0,
      resenasCount: 0,
      serviciosCompletados: 0,
      fechaAlta: defaultDate,
      fechaIngreso: defaultDate,
      ultimoAcceso: defaultDate,
      fechaActualizacion: defaultDate
    } as TherapistFullProfile;
  }

  // 1. Safe Names & Contacts
  const nombre = String(raw.nombre || raw.name || 'Terapeuta');
  const apellidos = String(raw.apellidos || '');
  const correo = String(raw.correo || raw.email || '');
  const telefono = String(raw.telefono || raw.phone || '');
  const fotografia = raw.fotografia || raw.photo || raw.photoURL || '';

  // 2. Status normalization (maps legacy or english variants)
  let rawStatus = String(raw.estado || raw.status || 'pendiente').toLowerCase();
  if (rawStatus === 'active' || rawStatus === 'disponible') rawStatus = 'activo';
  else if (rawStatus === 'pending') rawStatus = 'pendiente';
  else if (rawStatus === 'rejected') rawStatus = 'rechazado';
  else if (rawStatus === 'blocked' || rawStatus === 'suspendido' || rawStatus === 'suspended') rawStatus = 'bloqueado';
  else if (rawStatus === 'inactive') rawStatus = 'inactivo';
  const estado: AccountStatus = (['activo', 'inactivo', 'bloqueado', 'pendiente', 'rechazado'].includes(rawStatus)
    ? rawStatus
    : 'pendiente') as AccountStatus;

  // 3. Specialties normalization (accepts array, string comma-separated, or specialties)
  let especialidades: string[] = [];
  if (Array.isArray(raw.especialidades)) {
    especialidades = raw.especialidades.map((s: any) => String(s || '').trim()).filter(Boolean);
  } else if (Array.isArray(raw.specialties)) {
    especialidades = raw.specialties.map((s: any) => String(s || '').trim()).filter(Boolean);
  } else if (typeof raw.especialidades === 'string' && raw.especialidades.trim()) {
    especialidades = raw.especialidades.split(',').map((s: string) => s.trim()).filter(Boolean);
  } else if (typeof raw.specialties === 'string' && raw.specialties.trim()) {
    especialidades = raw.specialties.split(',').map((s: string) => s.trim()).filter(Boolean);
  }

  // 4. Coverage Zones normalization (zonasCobertura, coverageZones, zonasCoordinadas)
  let zonasCobertura: string[] = [];
  if (Array.isArray(raw.zonasCobertura)) {
    zonasCobertura = raw.zonasCobertura.map((z: any) => String(z || '').trim()).filter(Boolean);
  } else if (Array.isArray(raw.coverageZones)) {
    zonasCobertura = raw.coverageZones.map((z: any) => String(z || '').trim()).filter(Boolean);
  } else if (Array.isArray(raw.zonasCoordinadas)) {
    zonasCobertura = raw.zonasCoordinadas.map((z: any) => String(z || '').trim()).filter(Boolean);
  } else if (typeof raw.zonasCobertura === 'string' && raw.zonasCobertura.trim()) {
    zonasCobertura = raw.zonasCobertura.split(',').map((z: string) => z.trim()).filter(Boolean);
  } else if (typeof raw.coverageZones === 'string' && raw.coverageZones.trim()) {
    zonasCobertura = raw.coverageZones.split(',').map((z: string) => z.trim()).filter(Boolean);
  }

  // 5. Numerical metrics normalization (puntuacion/rating, resenasCount/reviewCount, serviciosCompletados/totalServices)
  const rawRating = typeof raw.puntuacion === 'number' ? raw.puntuacion : Number(raw.puntuacion || raw.rating);
  const puntuacion = !isNaN(rawRating) && rawRating > 0 ? rawRating : 5.0;

  const rawReviews = typeof raw.resenasCount === 'number' ? raw.resenasCount : Number(raw.resenasCount || raw.reviewCount);
  const resenasCount = !isNaN(rawReviews) && rawReviews >= 0 ? rawReviews : 0;

  const rawCompleted = typeof raw.serviciosCompletados === 'number' 
    ? raw.serviciosCompletados 
    : Number(raw.serviciosCompletados || raw.totalServices || raw.completedServicesCount);
  const serviciosCompletados = !isNaN(rawCompleted) && rawCompleted >= 0 ? rawCompleted : 0;

  // 6. Emergency Contact normalization (object or string)
  let contactoEmergencia: { nombre: string; parentesco: string; telefono: string } | undefined = undefined;
  if (raw.contactoEmergencia && typeof raw.contactoEmergencia === 'object') {
    contactoEmergencia = {
      nombre: String(raw.contactoEmergencia.nombre || raw.contactoEmergencia.name || ''),
      parentesco: String(raw.contactoEmergencia.parentesco || 'Familiar'),
      telefono: String(raw.contactoEmergencia.telefono || raw.contactoEmergencia.phone || '')
    };
  } else if (typeof raw.contactoEmergencia === 'string' && raw.contactoEmergencia.trim()) {
    contactoEmergencia = {
      nombre: raw.contactoEmergencia.trim(),
      parentesco: 'Familiar',
      telefono: ''
    };
  }

  // 7. Documents normalization (array or object map with robust field defaults)
  const rawDocs = Array.isArray(raw.documentos)
    ? raw.documentos
    : (raw.documentos && typeof raw.documentos === 'object' ? Object.values(raw.documentos) : []);

  const documentos: TherapistDocument[] = rawDocs
    .filter((d: any) => d && typeof d === 'object')
    .map((d: any, idx: number) => {
      const dId = String(d.id || `doc-${Date.now()}-${idx}`);
      const dName = String(d.nombreDocumento || d.nombre || d.name || 'Documento de Certificación');
      const dTipo = String(d.tipo || d.type || 'diploma');
      const dInst = String(d.institucion || d.institution || 'Institución Oficial');
      const dEmision = String(d.fechaEmision || d.emisionDate || 'No disponible');
      const dUrl = String(d.fileUrl || d.url || d.file_url || '');
      const dFileType = String(d.fileType || d.typeFormat || (dUrl.includes('.pdf') ? 'pdf' : 'archivo'));
      
      const rawDocEstado = String(d.estado || d.status || 'pendiente').toLowerCase();
      let dEstado: DocumentStatus = 'pendiente';
      if (rawDocEstado === 'aprobado' || rawDocEstado === 'validado' || rawDocEstado === 'approved') {
        dEstado = 'validado';
      } else if (rawDocEstado === 'rechazado' || rawDocEstado === 'rejected') {
        dEstado = 'rechazado';
      }

      return {
        id: dId,
        nombreDocumento: dName,
        tipo: dTipo,
        institucion: dInst,
        fechaEmision: dEmision,
        fileUrl: dUrl,
        fileType: dFileType,
        estado: dEstado,
        fechaSubida: d.fechaSubida || defaultDate,
        fechaRevision: d.fechaRevision || undefined,
        revisadoPor: d.revisadoPor || undefined,
        motivoRechazo: d.motivoRechazo ? String(d.motivoRechazo) : undefined
      };
    });

  return {
    ...raw,
    id: String(raw.id || raw.uid || `therapist-${Date.now()}`),
    nombre,
    apellidos,
    correo,
    telefono,
    fotografia,
    curp: raw.curp || raw.CURP || undefined,
    ineNumber: raw.ineNumber || raw.ine || raw.INE || undefined,
    cuentaBancariaCLABE: raw.cuentaBancariaCLABE || raw.clabe || raw.CLABE || undefined,
    direccion: raw.direccion || undefined,
    fechaNacimiento: raw.fechaNacimiento || undefined,
    certificacionesInfo: raw.certificacionesInfo || undefined,
    contactoEmergencia,
    especialidades,
    experienciaAnos: typeof raw.experienciaAnos === 'number' ? raw.experienciaAnos : 3,
    idiomas: Array.isArray(raw.idiomas) && raw.idiomas.length ? raw.idiomas : ['Español'],
    disponibilidad: raw.disponibilidad || 'Lunes a Sábado, 8:00 - 20:00',
    zonasCobertura,
    zonasCoordinadas: zonasCobertura,
    estado,
    documentos,
    puntuacion,
    resenasCount,
    serviciosCompletados,
    fechaAlta: raw.fechaAlta || raw.fechaIngreso || defaultDate,
    fechaIngreso: raw.fechaIngreso || raw.fechaAlta || defaultDate,
    ultimoAcceso: raw.ultimoAcceso || 'Nunca',
    fechaActualizacion: raw.fechaActualizacion || defaultDate
  } as TherapistFullProfile;
};

// Initial professional therapists dataset (starts clean for production)
const INITIAL_THERAPISTS: TherapistFullProfile[] = [];

export const TherapistProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [therapists, setTherapists] = useState<TherapistFullProfile[]>(() => {
    try {
      const stored = localStorage.getItem('essenya_therapists_list');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          return parsed.map(sanitizeTherapist);
        }
      }
      return INITIAL_THERAPISTS;
    } catch {
      return INITIAL_THERAPISTS;
    }
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    try {
      const stored = localStorage.getItem('essenya_therapist_audit_logs');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const [loading, setLoading] = useState(false);
  const [firestoreError, setFirestoreError] = useState<string | null>(null);
  const { firebaseUser } = useAuth();

  // Firestore Realtime Subscription for Therapists
  useEffect(() => {
    setLoading(true);
    const unsubscribe = onSnapshot(collection(db, 'terapeutas'), (snapshot) => {
      setFirestoreError(null);
      setLoading(false);
      if (snapshot.empty) {
        setTherapists([]);
        try {
          localStorage.setItem('essenya_therapists_list', JSON.stringify([]));
        } catch {}
      } else {
        const loaded: TherapistFullProfile[] = snapshot.docs
          .map(docSnap => {
            try {
              return sanitizeTherapist({
                id: docSnap.id,
                ...docSnap.data()
              });
            } catch (e) {
              console.error('Error sanitizing therapist profile:', docSnap.id, e);
              return null;
            }
          })
          .filter((t): t is TherapistFullProfile => t !== null);
        setTherapists(loaded);
      }
    }, (err) => {
      setLoading(false);
      const isPermissionDenied = err.code === 'permission-denied' || (err.message && err.message.includes('permission-denied'));
      if (isPermissionDenied) {
        console.error('Firestore permission-denied en colección "terapeutas":', err);
        setFirestoreError('No fue posible cargar las solicitudes de terapeutas.');
      } else {
        handleFirestoreError(err, OperationType.LIST, 'terapeutas');
        setFirestoreError('No fue posible cargar las solicitudes de terapeutas.');
      }
    });

    return () => unsubscribe();
  }, []);

  // Sync state to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('essenya_therapists_list', JSON.stringify(therapists));
    } catch {}
  }, [therapists]);

  useEffect(() => {
    try {
      localStorage.setItem('essenya_therapist_audit_logs', JSON.stringify(auditLogs));
    } catch {}
  }, [auditLogs]);

  // Log Audit Action
  const logAudit = useCallback((therapistId: string, therapistName: string, action: string, details?: string) => {
    const newLog: AuditLog = {
      id: `log-${Date.now()}`,
      therapistId,
      therapistName,
      action,
      performedBy: 'Administradora',
      timestamp: new Date().toISOString(),
      details
    };
    setAuditLogs(prev => [newLog, ...prev]);
  }, []);

  // Admin Operation: Create Therapist with Temporary Credentials
  const createTherapist = async (data: {
    id?: string;
    nombre: string;
    apellidos: string;
    correo: string;
    telefono: string;
    especialidades: string[];
    zonasCobertura: string[];
    tempPassword?: string;
    fotografia?: string;
    fechaNacimiento?: string;
    direccion?: string;
    curp?: string;
    ineNumber?: string;
    certificacionesInfo?: string;
    cuentaBancariaCLABE?: string;
    contactoEmergencia?: { nombre: string; parentesco: string; telefono: string };
    experienciaAnos?: number;
    disponibilidad?: string;
    estado?: AccountStatus;
  }): Promise<{ success: boolean; tempPassword?: string; error?: string }> => {
    const { nombre, apellidos, correo, telefono, especialidades, zonasCobertura } = data;

    // Validations
    if (!nombre.trim() || !apellidos.trim() || !correo.trim()) {
      return { success: false, error: 'Por favor completa el nombre, apellidos y correo electrónico.' };
    }

    const trimmedEmail = correo.trim().toLowerCase();
    // Auto generate strong temp password if not provided
    const tempPass = data.tempPassword || `Essenya${Math.floor(1000 + Math.random() * 9000)}!`;
    let finalId = data.id;

    if (!finalId) {
      // Provision Auth user in Firebase Auth via our secure backend endpoint
      try {
        const token = await auth.currentUser?.getIdToken();
        const headers: Record<string, string> = {
          'Content-Type': 'application/json'
        };
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }

        console.log('[createTherapist] Provisioning Auth account via server API...');
        const apiResponse = await fetch('/api/admin/create-therapist-auth-profile', {
          method: 'POST',
          headers,
          body: JSON.stringify({
            email: trimmedEmail,
            password: tempPass,
            displayName: `${nombre} ${apellidos}`.trim()
          })
        });

        if (!apiResponse.ok) {
          const errData = await apiResponse.json().catch(() => ({ error: 'Error del servidor backend' }));
          return { success: false, error: errData.error || `HTTP error ${apiResponse.status}` };
        }

        const apiResult = await apiResponse.json();
        if (apiResult.success && apiResult.uid) {
          finalId = apiResult.uid;
        } else {
          return { success: false, error: apiResult.error || 'No se recibió UID del servidor de autenticación.' };
        }
      } catch (err: any) {
        console.error('[createTherapist] Auth provisioning error:', err);
        return { success: false, error: `Error al crear la cuenta de autenticación: ${err.message || err}` };
      }
    }

    const initialStatus: AccountStatus = data.estado || 'activo';

    // Check duplicate: only error if there is another therapist with the same email and a DIFFERENT id
    const existingOther = therapists.find(t => (t.correo || '').toLowerCase() === trimmedEmail && t.id !== finalId);
    if (existingOther) {
      return { success: false, error: 'Ya existe una terapeuta registrada con este correo electrónico.' };
    }

    const newTherapist: TherapistFullProfile = {
      id: finalId,
      nombre: nombre.trim(),
      apellidos: apellidos.trim(),
      correo: trimmedEmail,
      telefono: telefono.trim(),
      fotografia: data.fotografia || '',
      fechaNacimiento: data.fechaNacimiento,
      direccion: data.direccion,
      curp: data.curp,
      ineNumber: data.ineNumber,
      certificacionesInfo: data.certificacionesInfo,
      cuentaBancariaCLABE: data.cuentaBancariaCLABE,
      contactoEmergencia: data.contactoEmergencia,
      especialidades: especialidades.length ? especialidades : ['Masaje Holístico'],
      experienciaAnos: data.experienciaAnos || 3,
      idiomas: ['Español'],
      disponibilidad: data.disponibilidad || 'Lunes a Sábado, 09:00 - 19:00',
      zonasCobertura: zonasCobertura.length ? zonasCobertura : ['Polanco'],
      estado: initialStatus,
      mustChangePassword: !data.id, // Only require password change if created by administrator
      documentos: [], // Start empty for real uploads only
      puntuacion: 5.0,
      resenasCount: 0,
      serviciosCompletados: 0,
      fechaAlta: new Date().toISOString(),
      ultimoAcceso: 'Nunca',
      fechaActualizacion: new Date().toISOString()
    };

    // Save to Firestore
    try {
      const userPayload = {
        id: finalId,
        nombre,
        apellidos,
        correo: trimmedEmail,
        telefono,
        estado: initialStatus,
        fechaRegistro: new Date().toISOString(),
        ultimoAcceso: 'Nunca',
        correoVerificado: true,
        rol: 'terapeuta',
        fechaActualizacion: new Date().toISOString(),
        mustChangePassword: !data.id
      };
      await setDoc(doc(db, 'users', finalId), cleanForFirestore(userPayload), { merge: true });
      await setDoc(doc(db, 'terapeutas', finalId), cleanForFirestore(newTherapist), { merge: true });
      
      if (initialStatus === 'activo') {
        const publicPayload = {
          id: finalId,
          name: `${nombre} ${apellidos}`.trim(),
          nombre: `${nombre} ${apellidos}`.trim(),
          photo: data.fotografia || '',
          fotografia: data.fotografia || '',
          phone: telefono,
          telefono,
          rating: 5.0,
          puntuacion: 5.0,
          reviewCount: 0,
          resenasCount: 0,
          specialties: especialidades,
          especialidades,
          status: 'disponible',
          estado: 'activo',
          coverageZones: zonasCobertura,
          zonasCobertura,
          completedServicesCount: 0,
          serviciosCompletados: 0,
          bio: data.certificacionesInfo || 'Terapeuta certificada ESSENYA.',
          biografia: data.certificacionesInfo || 'Terapeuta certificada ESSENYA.',
          updatedAt: new Date().toISOString()
        };
        try {
          await setDoc(doc(db, 'terapeutas_publicos', finalId), cleanForFirestore(publicPayload), { merge: true });
        } catch {}
      }

      setTherapists(prev => {
        const remaining = prev.filter(t => t.id !== finalId && (t.correo || '').toLowerCase() !== trimmedEmail);
        return [newTherapist, ...remaining];
      });
      logAudit(finalId, `${nombre} ${apellidos}`, initialStatus === 'pendiente' ? 'Postulación de Terapeuta Registrada' : 'Creación de Cuenta por Administradora', `Estado Inicial: ${initialStatus.toUpperCase()}`);
      
      return { success: true, tempPassword: tempPass };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.CREATE, `terapeutas/${finalId}`, newTherapist);
      return { success: false, error: err?.message || 'Error al registrar la terapeuta en la base de datos.' };
    }
  };

  // Admin Operation: Update Therapist
  const updateTherapist = async (id: string, updates: Partial<TherapistFullProfile>): Promise<{ success: boolean; error?: string }> => {
    let updatedName = '';
    const target = therapists.find(t => t.id === id);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    updatedName = `${updates.nombre || target.nombre} ${updates.apellidos || target.apellidos}`;

    const updatePayload = {
      ...updates,
      fechaActualizacion: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'terapeutas', id), cleanForFirestore(updatePayload));
      try {
        await updateDoc(doc(db, 'users', id), cleanForFirestore({
          fechaActualizacion: new Date().toISOString()
        }));
      } catch {}

      setTherapists(prev => prev.map(t => {
        if (t.id === id) {
          return {
            ...t,
            ...updates,
            fechaActualizacion: new Date().toISOString()
          };
        }
        return t;
      }));

      // Sync public directory if active
      if (target.estado === 'activo' || updates.estado === 'activo') {
        const publicUpdates = {
          name: updatedName.trim(),
          nombre: updatedName.trim(),
          photo: updates.fotografia || target.fotografia,
          fotografia: updates.fotografia || target.fotografia,
          phone: updates.telefono || target.telefono,
          telefono: updates.telefono || target.telefono,
          specialties: updates.especialidades || target.especialidades,
          especialidades: updates.especialidades || target.especialidades,
          coverageZones: updates.zonasCobertura || target.zonasCobertura,
          zonasCobertura: updates.zonasCobertura || target.zonasCobertura,
          bio: updates.biografia || target.biografia,
          biografia: updates.biografia || target.biografia,
          updatedAt: new Date().toISOString()
        };
        try {
          await updateDoc(doc(db, 'terapeutas_publicos', id), cleanForFirestore(publicUpdates));
        } catch {}
      }

      logAudit(id, updatedName, 'Modificación de Expediente', 'Perfil actualizado por la Administradora.');
      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${id}`, updatePayload);
      return { success: false, error: err?.message || 'Error al actualizar terapeuta en Firestore.' };
    }
  };

  // Admin Operation: Change Status (Activo, Inactivo, Bloqueado, Pendiente, Rechazado)
  const changeTherapistStatus = async (id: string, status: AccountStatus, reason?: string): Promise<{ success: boolean; error?: string }> => {
    let target = therapists.find(t => t.id === id);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    let realUid = id;

    // Check Firebase Auth account if approving
    if (status === 'activo') {
      let authExists = false;
      try {
        const token = await auth.currentUser?.getIdToken();
        const headers: Record<string, string> = {
          'Content-Type': 'application/json'
        };
        if (token) {
          headers['Authorization'] = `Bearer ${token}`;
        }

        const checkResponse = await fetch('/api/admin/verify-therapist-auth', {
          method: 'POST',
          headers,
          body: JSON.stringify({
            email: target.correo,
            uid: id
          })
        });

        if (checkResponse.ok) {
          const checkResult = await checkResponse.json();
          if (checkResult.success && checkResult.exists) {
            authExists = true;
            realUid = checkResult.uid;
          }
        }
      } catch (err) {
        console.warn('Error checking therapist auth existence:', err);
      }

      if (!authExists) {
        // If not found, and it is a self-registered therapist (who has documents uploaded), return clear error
        const isSelfRegistered = !target.mustChangePassword && target.documentos && target.documentos.length > 0;
        if (isSelfRegistered) {
          return { 
            success: false, 
            error: 'Error administrativo: No se encontró la cuenta de Firebase Authentication para esta terapeuta auto-registrada. No se puede proceder con la aprobación.' 
          };
        }

        // Admin-created: provision now
        try {
          const token = await auth.currentUser?.getIdToken();
          const headers: Record<string, string> = {
            'Content-Type': 'application/json'
          };
          if (token) {
            headers['Authorization'] = `Bearer ${token}`;
          }

          const tempPass = `Essenya${Math.floor(1000 + Math.random() * 9000)}!`;
          const createResponse = await fetch('/api/admin/create-therapist-auth-profile', {
            method: 'POST',
            headers,
            body: JSON.stringify({
              email: target.correo,
              password: tempPass,
              displayName: `${target.nombre} ${target.apellidos || ''}`.trim()
            })
          });

          if (!createResponse.ok) {
            const errData = await createResponse.json().catch(() => ({ error: 'Error del servidor backend' }));
            return { success: false, error: `No se pudo aprovisionar la cuenta de autenticación en Firebase Auth: ${errData.error}` };
          }

          const createResult = await createResponse.json();
          if (createResult.success && createResult.uid) {
            realUid = createResult.uid;
          } else {
            return { success: false, error: 'No se pudo crear la cuenta de autenticación en Firebase Auth.' };
          }
        } catch (err: any) {
          return { success: false, error: `Error de red al crear cuenta de autenticación: ${err.message}` };
        }
      }

      // If the UID changed (e.g. was a temporary generated local ID, and now we have a real Auth UID), migrate Firestore docs!
      if (realUid !== id) {
        try {
          const oldUserSnap = await getDoc(doc(db, 'users', id));
          const oldTherapistSnap = await getDoc(doc(db, 'terapeutas', id));

          const userData = oldUserSnap.exists() ? oldUserSnap.data() : null;
          const therapistData = oldTherapistSnap.exists() ? oldTherapistSnap.data() : null;

          if (userData) {
            await setDoc(doc(db, 'users', realUid), {
              ...userData,
              id: realUid,
              uid: realUid
            });
          }
          if (therapistData) {
            await setDoc(doc(db, 'terapeutas', realUid), {
              ...therapistData,
              id: realUid,
              userId: realUid
            });
          }

          // Delete old docs
          await deleteDoc(doc(db, 'users', id));
          await deleteDoc(doc(db, 'terapeutas', id));

          id = realUid;
          // Update the list of therapists context state immediately
          setTherapists(prev => prev.map(t => {
            if (t.id === target.id) {
              return { ...t, id: realUid };
            }
            return t;
          }));
          
          // Re-fetch target
          target = { ...target, id: realUid };
        } catch (migrationErr: any) {
          console.error('Error migrating Firestore documents to new real UID:', migrationErr);
        }
      }
    }

    const rejectionReason = status === 'rechazado' ? (reason || 'No cumple con los requisitos de acreditación.') : undefined;

    const statusLabel = 
      status === 'activo' ? 'Aprobada / Activada' : 
      status === 'rechazado' ? 'Rechazada' : 
      status === 'pendiente' ? 'Puesta en Revisión Pendiente' : 
      status === 'inactivo' ? 'Desactivada' : 'Suspendida / Bloqueada';

    const statusPayload = {
      estado: status,
      motivoRechazoAccount: rejectionReason || null,
      fechaActualizacion: new Date().toISOString(),
      ...(status === 'activo' ? {
        fechaAprobacion: new Date().toISOString(),
        aprobadoPor: auth.currentUser?.email || 'admin@essenya.mx'
      } : {})
    };

    try {
      await updateDoc(doc(db, 'terapeutas', id), cleanForFirestore(statusPayload));
      try {
        await updateDoc(doc(db, 'users', id), cleanForFirestore({
          estado: status,
          fechaActualizacion: new Date().toISOString(),
          ...(status === 'activo' ? {
            fechaAprobacion: new Date().toISOString(),
            aprobadoPor: auth.currentUser?.email || 'admin@essenya.mx'
          } : {})
        }));
      } catch {}

      // Sync with terapeutas_publicos collection for client visibility
      if (status === 'activo') {
        const publicPayload = {
          id: target.id,
          name: `${target.nombre} ${target.apellidos || ''}`.trim(),
          nombre: `${target.nombre} ${target.apellidos || ''}`.trim(),
          photo: target.fotografia || '',
          fotografia: target.fotografia || '',
          phone: target.telefono || '',
          telefono: target.telefono || '',
          rating: target.puntuacion || 5.0,
          puntuacion: target.puntuacion || 5.0,
          reviewCount: target.resenasCount || 0,
          resenasCount: target.resenasCount || 0,
          specialties: target.especialidades || ['Masaje Relajante'],
          especialidades: target.especialidades || ['Masaje Relajante'],
          status: 'disponible',
          estado: 'activo',
          coverageZones: target.zonasCobertura || ['Polanco'],
          zonasCobertura: target.zonasCobertura || ['Polanco'],
          completedServicesCount: target.serviciosCompletados || 0,
          serviciosCompletados: target.serviciosCompletados || 0,
          bio: target.biografia || 'Terapeuta certificada ESSENYA.',
          biografia: target.biografia || 'Terapeuta certificada ESSENYA.',
          updatedAt: new Date().toISOString()
        };
        try {
          await setDoc(doc(db, 'terapeutas_publicos', id), cleanForFirestore(publicPayload), { merge: true });
        } catch {}
      } else {
        try {
          await updateDoc(doc(db, 'terapeutas_publicos', id), {
            status: 'desconectado',
            estado: status,
            updatedAt: new Date().toISOString()
          });
        } catch {}
      }

      setTherapists(prev => prev.map(t => {
        if (t.id === id) {
          return { 
            ...t, 
            estado: status, 
            motivoRechazoAccount: rejectionReason, 
            fechaActualizacion: new Date().toISOString() 
          };
        }
        return t;
      }));

      logAudit(id, `${target.nombre} ${target.apellidos}`, `Estado Cambiado a: ${statusLabel}`, reason || 'Acción ejecutada por Administradora.');
      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${id}`, statusPayload);
      return { success: false, error: err?.message || 'Error al modificar el estado de la cuenta.' };
    }
  };

  // Admin Operation: Reset Password
  const resetTherapistPassword = async (id: string): Promise<{ success: boolean; message?: string; tempPassword?: string; error?: string }> => {
    const target = therapists.find(t => t.id === id);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    try {
      // 1. Send official Firebase Authentication password reset email
      if (target.correo) {
        const trimmed = target.correo.trim().toLowerCase();
        const origin = window.location.origin;
        try {
          await sendPasswordResetEmail(auth, trimmed, {
            url: `${origin}/login`,
            handleCodeInApp: false
          });
        } catch (e: any) {
          const errStr = (e?.code || '') + ' ' + (e?.message || '');
          if (errStr.includes('auth/user-not-found')) {
            return {
              success: false,
              error: 'Error: El correo electrónico de esta terapeuta no está registrado en Firebase Authentication. Crea la cuenta o verifícala primero.'
            };
          }
          console.warn('Could not send admin-initiated therapist reset email with ActionCodeSettings, trying default reset:', e);
          try {
            await sendPasswordResetEmail(auth, trimmed);
          } catch (e2: any) {
            const errStr2 = (e2?.code || '') + ' ' + (e2?.message || '');
            if (errStr2.includes('auth/user-not-found')) {
              return {
                success: false,
                error: 'Error: El correo electrónico de esta terapeuta no está registrado en Firebase Authentication. No se puede restablecer la contraseña.'
              };
            }
            throw e2;
          }
        }
      }

      // 2. Mark mustChangePassword in Firestore
      await updateDoc(doc(db, 'terapeutas', id), {
        mustChangePassword: true,
        fechaActualizacion: new Date().toISOString()
      });
      try {
        await updateDoc(doc(db, 'users', id), {
          mustChangePassword: true,
          fechaActualizacion: new Date().toISOString()
        });
      } catch {}

      setTherapists(prev => prev.map(t => {
        if (t.id === id) {
          return { ...t, mustChangePassword: true, fechaActualizacion: new Date().toISOString() };
        }
        return t;
      }));

      logAudit(id, `${target.nombre} ${target.apellidos}`, 'Restablecimiento Oficial de Contraseña', `Enlace de recuperación emitido y enviado a ${target.correo}.`);

      return { 
        success: true, 
        message: `Se ha enviado el enlace oficial de restablecimiento a ${target.correo}.` 
      };
    } catch (err: any) {
      console.error('Password reset failed for therapist:', err);
      return { 
        success: false, 
        error: err?.message || 'No se pudo enviar el correo de restablecimiento de contraseña.' 
      };
    }
  };

  // Admin Operation: Delete Therapist
  const deleteTherapist = async (id: string): Promise<{ success: boolean; error?: string }> => {
    const target = therapists.find(t => t.id === id);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    try {
      await deleteDoc(doc(db, 'terapeutas', id));
      try {
        await deleteDoc(doc(db, 'users', id));
      } catch {}
      try {
        await deleteDoc(doc(db, 'terapeutas_publicos', id));
      } catch {}

      setTherapists(prev => prev.filter(t => t.id !== id));
      logAudit(id, `${target.nombre} ${target.apellidos}`, 'Eliminación de Cuenta', 'Cuenta eliminada permanentemente del sistema.');

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.DELETE, `terapeutas/${id}`);
      return { success: false, error: err?.message || 'Error al eliminar terapeuta de Firestore.' };
    }
  };

  // Admin Document Review (Approve or Reject with Reason)
  const reviewDocument = async (
    therapistId: string, 
    documentId: string, 
    status: DocumentStatus, 
    motivoRechazo?: string
  ): Promise<{ success: boolean; error?: string }> => {
    const target = therapists.find(t => t.id === therapistId);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    const statusNormalized = status === 'aprobado' ? 'validado' : status;
    const updatedDocs = target.documentos.map(doc => {
      if (doc.id === documentId) {
        return {
          ...doc,
          estado: statusNormalized,
          fechaRevision: new Date().toISOString(),
          revisadoPor: 'Administradora ESSENYA',
          motivoRechazo: statusNormalized === 'rechazado' ? motivoRechazo || 'Documento ilegible o vencido.' : undefined
        };
      }
      return doc;
    });

    const updatePayload = {
      documentos: updatedDocs,
      fechaActualizacion: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'terapeutas', therapistId), cleanForFirestore(updatePayload));

      setTherapists(prev => prev.map(t => {
        if (t.id === therapistId) {
          return { ...t, documentos: updatedDocs, fechaActualizacion: new Date().toISOString() };
        }
        return t;
      }));

      logAudit(
        therapistId, 
        `${target.nombre} ${target.apellidos}`, 
        `Revisión de Documento (${statusNormalized.toUpperCase()})`, 
        statusNormalized === 'rechazado' ? `Motivo: ${motivoRechazo}` : 'Documento validado y certificado por Admin.'
      );

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${therapistId}`, updatePayload);
      return { success: false, error: err?.message || 'Error al guardar la revisión en Firestore.' };
    }
  };

  // Therapist Operation: Upload Document
  const uploadDocument = async (
    therapistId: string, 
    docData: Omit<TherapistDocument, 'id' | 'estado' | 'fechaSubida'>
  ): Promise<{ success: boolean; error?: string }> => {
    const target = therapists.find(t => t.id === therapistId);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    const inferredMime = docData.fileType === 'pdf' ? 'application/pdf' : (docData.fileType === 'png' ? 'image/png' : 'image/jpeg');
    const timestamp = Date.now();
    const cleanFileName = docData.nombreDocumento.replace(/[^a-zA-Z0-9.-]/g, '_') + '.' + docData.fileType;

    const newDoc: TherapistDocument = {
      ...docData,
      id: `doc-${timestamp}`,
      estado: 'pendiente',
      fechaSubida: new Date().toISOString(),
      nombreArchivo: cleanFileName,
      mimeType: inferredMime,
      fechaCarga: new Date().toISOString(),
      estadoRevision: 'pendiente'
    };

    const updatedDocs = [...target.documentos, newDoc];
    const updatePayload = {
      documentos: updatedDocs,
      fechaActualizacion: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'terapeutas', therapistId), cleanForFirestore(updatePayload));

      setTherapists(prev => prev.map(t => {
        if (t.id === therapistId) {
          return {
            ...t,
            documentos: updatedDocs,
            fechaActualizacion: new Date().toISOString()
          };
        }
        return t;
      }));

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${therapistId}`, updatePayload);
      return { success: false, error: err?.message || 'Error al subir documento.' };
    }
  };

  // Therapist Operation: Replace Document (e.g. resubmitting a rejected or updated document)
  const replaceDocument = async (
    therapistId: string,
    documentId: string,
    docData: Partial<Omit<TherapistDocument, 'id' | 'estado' | 'fechaSubida'>>
  ): Promise<{ success: boolean; error?: string }> => {
    const target = therapists.find(t => t.id === therapistId);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    const inferredMime = docData.fileType === 'pdf' ? 'application/pdf' : (docData.fileType === 'png' ? 'image/png' : 'image/jpeg');
    const cleanFileName = (docData.nombreDocumento || 'documento').replace(/[^a-zA-Z0-9.-]/g, '_') + '.' + (docData.fileType || 'pdf');

    const updatedDocs = target.documentos.map(d => {
      if (d.id === documentId) {
        return {
          ...d,
          ...docData,
          estado: 'pendiente' as DocumentStatus,
          motivoRechazo: undefined,
          fechaSubida: new Date().toISOString(),
          fechaRevision: undefined,
          revisadoPor: undefined,
          nombreArchivo: cleanFileName,
          mimeType: inferredMime,
          fechaCarga: new Date().toISOString(),
          estadoRevision: 'pendiente'
        };
      }
      return d;
    });

    const updatePayload = {
      documentos: updatedDocs,
      fechaActualizacion: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'terapeutas', therapistId), cleanForFirestore(updatePayload));

      setTherapists(prev => prev.map(t => {
        if (t.id === therapistId) {
          return {
            ...t,
            documentos: updatedDocs,
            fechaActualizacion: new Date().toISOString()
          };
        }
        return t;
      }));

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${therapistId}`, updatePayload);
      return { success: false, error: err?.message || 'Error al reemplazar documento.' };
    }
  };

  // Therapist Operation: Delete Document
  const deleteDocument = async (
    therapistId: string,
    documentId: string
  ): Promise<{ success: boolean; error?: string }> => {
    const target = therapists.find(t => t.id === therapistId);
    if (!target) return { success: false, error: 'Terapeuta no encontrada.' };

    const updatedDocs = target.documentos.filter(d => d.id !== documentId);
    const updatePayload = {
      documentos: updatedDocs,
      fechaActualizacion: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'terapeutas', therapistId), cleanForFirestore(updatePayload));

      setTherapists(prev => prev.map(t => {
        if (t.id === therapistId) {
          return {
            ...t,
            documentos: updatedDocs,
            fechaActualizacion: new Date().toISOString()
          };
        }
        return t;
      }));

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${therapistId}`, updatePayload);
      return { success: false, error: err?.message || 'Error al eliminar documento.' };
    }
  };

  // Therapist Operation: Update Self Profile
  const updateSelfProfile = async (
    therapistId: string, 
    updates: Partial<TherapistFullProfile>
  ): Promise<{ success: boolean; error?: string }> => {
    const updatePayload = {
      ...updates,
      fechaActualizacion: new Date().toISOString()
    };

    try {
      await updateDoc(doc(db, 'terapeutas', therapistId), cleanForFirestore(updatePayload));

      // Sync photograph or basic fields with users and terapeutas_publicos collections
      if (updates.fotografia !== undefined) {
        try {
          await updateDoc(doc(db, 'users', therapistId), {
            fotografia: updates.fotografia,
            fechaActualizacion: new Date().toISOString()
          });
        } catch (err) {
          console.warn('Error syncing photograph with users collection:', err);
        }

        try {
          const publicDocRef = doc(db, 'terapeutas_publicos', therapistId);
          const publicDocSnap = await getDoc(publicDocRef);
          if (publicDocSnap.exists()) {
            await updateDoc(publicDocRef, {
              fotografia: updates.fotografia,
              updatedAt: new Date().toISOString()
            });
          }
        } catch (err) {
          console.warn('Error syncing photograph with terapeutas_publicos:', err);
        }
      }

      setTherapists(prev => prev.map(t => {
        if (t.id === therapistId) {
          return {
            ...t,
            ...updates,
            fechaActualizacion: new Date().toISOString()
          };
        }
        return t;
      }));

      return { success: true };
    } catch (err: any) {
      handleFirestoreError(err, OperationType.UPDATE, `terapeutas/${therapistId}`, updatePayload);
      return { success: false, error: err?.message || 'Error al actualizar perfil.' };
    }
  };

  const getTherapistById = (id: string) => {
    return therapists.find(t => t.id === id);
  };

  return (
    <TherapistContext.Provider
      value={{
        therapists,
        auditLogs,
        loading,
        firestoreError,
        createTherapist,
        updateTherapist,
        changeTherapistStatus,
        resetTherapistPassword,
        deleteTherapist,
        reviewDocument,
        uploadDocument,
        replaceDocument,
        deleteDocument,
        updateSelfProfile,
        getTherapistById
      }}
    >
      {children}
    </TherapistContext.Provider>
  );
};

export const useTherapistContext = () => {
  const context = useContext(TherapistContext);
  if (!context) {
    throw new Error('useTherapistContext must be used within a TherapistProvider');
  }
  return context;
};

