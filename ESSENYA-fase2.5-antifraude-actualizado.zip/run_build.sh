npm run typecheck && npm run build
